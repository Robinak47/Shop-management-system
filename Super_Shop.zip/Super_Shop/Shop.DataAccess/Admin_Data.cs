﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.Framework;
using System.Data.SqlClient;
using System.Data;
using Shop.Entities;

namespace Shop.DataAccess
{
    public class Admin_Data
    {
        public void InserAdmin(AdminD admin)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("INSERT INTO admin VALUES(@adminid,@adminname,@adminphone,@adminage,@adminaddress,@admingender,@adminsecurity,@adminstatus)");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@adminid", admin.Admin_Id);
            cmd.Parameters.AddWithValue("@adminname", admin.Admin_Name);
            cmd.Parameters.AddWithValue("@adminphone", admin.Admin_Phone);
            cmd.Parameters.AddWithValue("@adminage", admin.Admin_Age);
            cmd.Parameters.AddWithValue("@adminaddress", admin.Admin_Address);
            cmd.Parameters.AddWithValue("@admingender", admin.Admin_Gender);
            cmd.Parameters.AddWithValue("@adminsecurity", admin.Admin_Security);
            cmd.Parameters.AddWithValue("@adminstatus", admin.Admin_ActiveStatus);



            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();



        }

       
        
          public  List<AdminD> GetData(SqlCommand cmd)
            {
                     cmd.Connection.Open();
                    SqlDataReader reader = cmd.ExecuteReader();
                    List<AdminD> list = new List<AdminD>();
                    using (reader)
                    {
                    while (reader.Read())
                    {
                    AdminD obj = new AdminD();
                    obj.Admin_Id = reader.GetString(0);
                    obj.Admin_Name = reader.GetString(1);
                    obj.Admin_Phone = reader.GetInt32(2);
                    obj.Admin_Age = reader.GetInt32(3);
                    obj.Admin_Address = reader.GetString(4);
                    obj.Admin_Gender = reader.GetString(5);
                    obj.Admin_Security = reader.GetString(6);
                    obj.Admin_ActiveStatus = reader.GetString(7);
                    list.Add(obj);
                    }
                    reader.Close();
                    }
                    cmd.Connection.Close();
                    return list;
          }

          public List<AdminD> GetAdminList()
          {
              SqlDbDataAccess da = new SqlDbDataAccess();
              SqlCommand cmd = da.GetCommand("SELECT * from admin WHERE adminstatus=@adminstatus");
              cmd.CommandType = CommandType.Text;
              cmd.Parameters.AddWithValue("@adminstatus", "active");
              List<AdminD> adminList = GetData(cmd);
              return adminList;
          }

          public void DeleteAdmin(string Id)

          {

              SqlDbDataAccess da = new SqlDbDataAccess();
              SqlCommand cmd = da.GetCommand("UPDATE admin SET adminstatus=@status WHERE adminid=@id");
              cmd.CommandType = CommandType.Text;
              cmd.Parameters.AddWithValue("@id",Id);
              cmd.Parameters.AddWithValue("@status", "inactive");
              cmd.Connection.Open();


              cmd.ExecuteNonQuery();
              cmd.Connection.Close();


          }

          public void UpdateAdmin(string Id,int phoneno)
          {

              SqlDbDataAccess da = new SqlDbDataAccess();
              SqlCommand cmd = da.GetCommand("UPDATE admin SET adminphone=@phoneno WHERE adminid=@id");
              cmd.CommandType = CommandType.Text;
              cmd.Parameters.AddWithValue("@id", Id);
              cmd.Parameters.AddWithValue("@phoneno", phoneno);
              cmd.Connection.Open();


              cmd.ExecuteNonQuery();
              cmd.Connection.Close();


          }

        
    }
}
