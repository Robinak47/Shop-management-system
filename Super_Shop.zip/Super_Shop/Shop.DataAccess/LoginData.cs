﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.Framework;
using  System.Data.SqlClient;
using System.Data;
using Shop.Entities;

namespace Shop.DataAccess
{
    public class LoginData
    {

       

        public User getuser(string userId,string password)
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT * from login WHERE userid = '"+userId+"' and password = '"+password +"'");
            User user=new User();
             user= GetData(cmd);
            return user ;
        }

        User GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            User obj = new User();
            using (reader)
            {
                while (reader.Read())
                {

                    obj.UserId = reader.GetString(0);
                    obj.Password = reader.GetString(1);
                    obj.Active_status = reader.GetString(2);
                    obj.Status = reader.GetInt32(3);
                } 
                
                reader.Close();
            }
            cmd.Connection.Close();
            return obj;
        }


        public void Update_Password(string user_id, string password)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE login SET password=@password  WHERE userid=@user_id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@password", password);
            cmd.Parameters.AddWithValue("@user_id", user_id);
            cmd.Connection.Open();

           
            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }

        public string SearchPassword(string userid)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT password from login WHERE userid = '" + userid + "'");
            string password="";
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            
            using (reader)
            {
                while (reader.Read())
                {

                    string c;
                    c = reader.GetString(0);
                    password = c;



                }

                reader.Close();
            }

            cmd.Connection.Close();
            
            return password;

        }

        public void InsertUser(User user)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("INSERT INTO login VALUES(@userid,@password,@activestatus,@status,@security)");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@userid", user.UserId);
            cmd.Parameters.AddWithValue("@password", user.Password);
            cmd.Parameters.AddWithValue("@activestatus", user.Active_status);
            cmd.Parameters.AddWithValue("@status", user.Status);
            cmd.Parameters.AddWithValue("@security", user.Security);
           
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();



        }


        public void UpdateUser(string user_id, string status)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE login SET activestatus=@status WHERE userid=@user_id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@user_id", user_id);
            cmd.Parameters.AddWithValue("@status", status);
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }


        public User finduser(string userId, string security)
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT * from login WHERE userid = '" + userId + "' and security = '" + security + "'");
            User user = new User();
            user = GetData(cmd);
            return user;
        }

        



        
        

    }
}
