﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.Framework;
using System.Data.SqlClient;
using System.Data;
using Shop.Entities;

namespace Shop.DataAccess
{
    public class Customer_Data
    {
        public List<CustomerD> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<CustomerD> list = new List<CustomerD>();
            using (reader)
            {
                while (reader.Read())
                {
                    CustomerD obj = new CustomerD();
                    obj.Customer_Id = reader.GetString(0);
                    obj.Customer_Name= reader.GetString(1);
                    obj.Customer_Phone = reader.GetInt32(2);
                  
                    obj.Customer_Address = reader.GetString(3);
                    obj.Customer_Age = reader.GetInt32(4);
                    obj.Customer_Gender = reader.GetString(5);
                    obj.Customer_Status = reader.GetString(6);
                    obj.Customer_Security = reader.GetString(7);
                    

                    
                    list.Add(obj);
                }
                reader.Close();
            }
            cmd.Connection.Close();
            return list;
        }

        public List<CustomerD> GetCustomerList()
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT * from customer WHERE customerstatus=@customerstatus");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@customerstatus", "active");
            List<CustomerD> customerList = GetData(cmd);
            return customerList;
        }

        public void InsertCustomer(CustomerD customer)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("INSERT INTO customer VALUES(@customerid,@customername,@customerphone,@customeraddress,@customerage,@customergender,@customerstatus,@customersecurity)");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@customerid", customer.Customer_Id);
            cmd.Parameters.AddWithValue("@customername", customer.Customer_Name);
            cmd.Parameters.AddWithValue("@customerphone", customer.Customer_Phone);
            cmd.Parameters.AddWithValue("@customeraddress", customer.Customer_Address);
            cmd.Parameters.AddWithValue("@customerage", customer.Customer_Age);
            cmd.Parameters.AddWithValue("@customergender", customer.Customer_Gender);
            cmd.Parameters.AddWithValue("@customerstatus", customer.Customer_Status);
            cmd.Parameters.AddWithValue("@customersecurity", customer.Customer_Security);



            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();



        }


        public void DeleteCustomer(string Id)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE customer SET customerstatus=@status WHERE customerid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@status", "inactive");
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }

        public void UpdateSelfInfo(string Id, int phoneno)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE customer SET customerphone=@phoneno WHERE customerid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@phoneno", phoneno);
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }

        public void UpdateCustomer(string Id, string name)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE customer SET customername=@name WHERE customerid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@name", name);
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }


        public CustomerD getCustomer(string Id)
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT * from customer WHERE customerid = '" + Id + "'");
            CustomerD p = new CustomerD();
            p = GetData1(cmd);
            return p;
        }
        CustomerD GetData1(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            CustomerD obj = new CustomerD();
            using (reader)
            {
                while (reader.Read())
                {

                    obj.Customer_Id = reader.GetString(0);
                    obj.Customer_Name = reader.GetString(1);
                    obj.Customer_Phone = reader.GetInt32(2);
                    obj.Customer_Address = reader.GetString(3);
                    obj.Customer_Age = reader.GetInt32(4);
                    obj.Customer_Gender = reader.GetString(5);
                    obj.Customer_Status= reader.GetString(6);
                    obj.Customer_Security= reader.GetString(7);
                }

                reader.Close();
            }
            cmd.Connection.Close();
            return obj;
        }
    }
}
