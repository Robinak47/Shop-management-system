﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.Framework;
using System.Data.SqlClient;
using System.Data;
using Shop.Entities;

namespace Shop.DataAccess
{
    public class Order_Line_Data
    {
        public List<Order_LineD> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<Order_LineD> list = new List<Order_LineD>();
            using (reader)
            {
                while (reader.Read())
                {
                    Order_LineD obj = new Order_LineD();
                    obj.Order_Id = reader.GetString(0);
                    obj.Product_Id = reader.GetString(1);
                    obj.Quantity = reader.GetInt32(2);
                    obj.Price = reader.GetInt32(3);
                    

                    list.Add(obj);
                }
                reader.Close();
            }
            cmd.Connection.Close();
            return list;
        }

        public List<Order_LineD> GetOrder_LineList(string orderid)

        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT * from orderline WHERE orderid=@orderid");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@orderid", orderid);
            List<Order_LineD> orderList = GetData(cmd);
            return orderList;
        }

        public void InsertOrder_Line(Order_LineD o)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("INSERT INTO orderline VALUES(@orderid,@productid,@quantity,@price)");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@orderid",o.Order_Id);
            cmd.Parameters.AddWithValue("@productid", o.Product_Id);
            cmd.Parameters.AddWithValue("@quantity", o.Quantity);
            cmd.Parameters.AddWithValue("@price", o.Price);
            




            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();



        }

        public void DeleteOrder_Line(string Id,string pid)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("DELETE FROM orderline WHERE orderid=@id AND productid=@pid");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@pid", pid);
           
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }

        public void UpdateOrder_Line(string rId,string pid, int quantity, int price)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE orderline SET quantity=@quantity, price=@price WHERE orderid=@rid AND productid=@pid ");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@rid", rId);
            cmd.Parameters.AddWithValue("@pid", pid);
            cmd.Parameters.AddWithValue("@quantity", quantity);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }
    }
}
