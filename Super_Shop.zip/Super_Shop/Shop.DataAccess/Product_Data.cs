﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.Framework;
using System.Data.SqlClient;
using System.Data;
using Shop.Entities;

namespace Shop.DataAccess
{
    public class Product_Data
    {
        public List<ProductD> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<ProductD> list = new List<ProductD>();
            using (reader)
            {
                while (reader.Read())
                {
                    ProductD obj = new ProductD();
                    obj.Product_Id = reader.GetString(0);
                    obj.Product_Name = reader.GetString(1);
                    obj.Quantity = reader.GetInt32(2);
                    obj.Price = reader.GetInt32(3);
                    obj.Product_Status = reader.GetString(4);
               
                    list.Add(obj);
                }
                reader.Close();
            }
            cmd.Connection.Close();
            return list;
        }

        public List<ProductD> GetProductList()
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT * from product WHERE productstatus=@productstatus");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@productstatus", "active");
            List<ProductD> productList = GetData(cmd);
            return productList;
        }

        public void InsertProduct(ProductD product)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("INSERT INTO product VALUES(@productid,@productname,@quantity,@price,@poductstatus)");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@productid", product.Product_Id);
            cmd.Parameters.AddWithValue("@productname", product.Product_Name);
            cmd.Parameters.AddWithValue("@quantity", product.Quantity);
            cmd.Parameters.AddWithValue("@price", product.Price);
            cmd.Parameters.AddWithValue("@poductstatus", product.Product_Status);
           



            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();



        }


        public void DeleteProduct(string Id)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE product SET productstatus=@status WHERE productid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@status", "inactive");
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }

        public void UpdateProduct(string Id, int quantity,int price)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE product SET quantity=@quantity, price=@price WHERE productid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@quantity", quantity);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }


        public ProductD getProduct(string Id)
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT * from product WHERE productid = '" + Id + "'");
            ProductD p = new ProductD();
            p = GetData1(cmd);
            return p;
        }
        ProductD GetData1(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();

            ProductD obj = new ProductD();
            using (reader)
            {
                while (reader.Read())
                {

                    obj.Product_Id = reader.GetString(0);
                    obj.Product_Name = reader.GetString(1);
                    obj.Quantity = reader.GetInt32(2); 
                    obj.Price = reader.GetInt32(3);
                    obj.Product_Status = reader.GetString(4);
                }

                reader.Close();
            }
            cmd.Connection.Close();
            return obj;
        }
    }
}
