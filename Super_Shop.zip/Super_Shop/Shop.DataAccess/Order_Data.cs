﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.Framework;
using System.Data.SqlClient;
using System.Data;
using Shop.Entities;

namespace Shop.DataAccess
{
    public class Order_Data
    {
        public List<OrderD> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<OrderD> list = new List<OrderD>();
            using (reader)
            {
                while (reader.Read())
                {
                    OrderD obj = new OrderD();
                    obj.orderId = reader.GetString(0);
                    obj.Customer_Id = reader.GetString(1);
                    obj.Total_Amount = reader.GetInt32(2);
                    

                    list.Add(obj);
                }
                reader.Close();
            }
            cmd.Connection.Close();
            return list;
        }

        public List<OrderD> GetOrderList()
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT [orderid],[customerid],[totalamount] FROM [ShopDB].[dbo].[order]");
            cmd.CommandType = CommandType.Text;
            List<OrderD> orderList = GetData(cmd);
            return orderList;
        }

        public List<OrderD> GetOrderList1(String Id)
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT [orderid],[customerid],[totalamount] FROM [ShopDB].[dbo].[order] Where [customerid]=@id ");
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.CommandType = CommandType.Text;
            List<OrderD> orderList = GetData(cmd);
            return orderList;
        }

        public void InsertOrder(OrderD o)

        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("INSERT INTO [ShopDB].[dbo].[order] VALUES(@orderid,@customerid,@totalamount)");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@orderid", o.orderId);
            cmd.Parameters.AddWithValue("@customerid", o.Customer_Id);
            cmd.Parameters.AddWithValue("@totalamount", o.Total_Amount);


            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();



        }

        public void DeleteOrder(string Id)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("DELETE FROM order WHERE orderid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);

            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }

        public void UpdateOrder(string rId,  int price)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE order SET  totalamount=@price WHERE orderid=@rid ");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@rid", rId);
            cmd.Parameters.AddWithValue("@price", price);
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }
    }
}
