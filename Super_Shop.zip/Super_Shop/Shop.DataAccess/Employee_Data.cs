﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Shop.Framework;
using System.Data.SqlClient;
using System.Data;
using Shop.Entities;

namespace Shop.DataAccess
{
   public class Employee_Data
    {
        public void InserEmployee(EmployeeD employee)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("INSERT INTO employee VALUES(@employeeid,@employeename,@employeephone,@employeeage,@employeegender,@employeedesignation,@employeesalary,@employeeaddress,@employeesecurity,@employeestatus)");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@employeeid", employee.Employee_Id);
            cmd.Parameters.AddWithValue("@employeename", employee.Employee_Name);
            cmd.Parameters.AddWithValue("@employeephone", employee.Employee_Phone);
            cmd.Parameters.AddWithValue("@employeeage", employee.Employee_Age);
            cmd.Parameters.AddWithValue("@employeegender", employee.Employee_Gender);
            cmd.Parameters.AddWithValue("@employeedesignation", employee.Employee_Designation);
            cmd.Parameters.AddWithValue("@employeesalary", employee.Employee_Salary);
            cmd.Parameters.AddWithValue("@employeeaddress", employee.Employee_Addresss);
            cmd.Parameters.AddWithValue("@employeesecurity", employee.Employee_Security);
            cmd.Parameters.AddWithValue("@employeestatus", employee.Employee_Status);



            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();



        }



        public List<EmployeeD> GetData(SqlCommand cmd)
        {
            cmd.Connection.Open();
            SqlDataReader reader = cmd.ExecuteReader();
            List<EmployeeD> list = new List<EmployeeD>();
            using (reader)
            {
                while (reader.Read())
                {
                    EmployeeD obj = new EmployeeD();
                    obj.Employee_Id = reader.GetString(0);
                    obj.Employee_Name = reader.GetString(1);
                    obj.Employee_Phone = reader.GetInt32(2);
                    obj.Employee_Age = reader.GetInt32(3);
                    obj.Employee_Gender = reader.GetString(4);
                    obj.Employee_Designation = reader.GetString(5);
                    obj.Employee_Salary = reader.GetInt32(6);
                    
                    obj.Employee_Addresss = reader.GetString(7);
                    obj.Employee_Security = reader.GetString(8);
                    obj.Employee_Status = reader.GetString(9);
                    list.Add(obj);
                }
                reader.Close();
            }
            cmd.Connection.Close();
            return list;
        }

        public List<EmployeeD> GetEmployeeList()
        {
            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("SELECT * from employee WHERE employeestatus=@employeestatus");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@employeestatus", "active");
            List<EmployeeD> empList = GetData(cmd);
            return  empList;
        }

        public void DeleteEmployee(string Id)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE employee SET  employeestatus=@status WHERE employeeid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@status", "inactive");
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }

        public void UpdateEmployee(string Id,string designation,string salary)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE employee SET  employeedesignation=@designation,employeesalary=@salary WHERE employeeid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@designation", designation);
            cmd.Parameters.AddWithValue("@salary", salary);
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }
        public void UpdateEmployee1(string Id, int phoneno)
        {

            SqlDbDataAccess da = new SqlDbDataAccess();
            SqlCommand cmd = da.GetCommand("UPDATE employee SET employeephone=@phoneno WHERE employeeid=@id");
            cmd.CommandType = CommandType.Text;
            cmd.Parameters.AddWithValue("@id", Id);
            cmd.Parameters.AddWithValue("@phoneno", phoneno);
            cmd.Connection.Open();


            cmd.ExecuteNonQuery();
            cmd.Connection.Close();


        }

    }
}
