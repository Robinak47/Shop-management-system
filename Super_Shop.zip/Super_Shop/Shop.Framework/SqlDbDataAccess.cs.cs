﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;
namespace Shop.Framework
{
    public class SqlDbDataAccess
    {
        const string ConnectiosnString = "Data Source=DESKTOP-9QEJ0PU;Initial Catalog=ShopDB;Integrated Security=True";
            public SqlCommand GetCommand(String query)
            {
                var connection = new SqlConnection(ConnectiosnString);
                SqlCommand cmd = new SqlCommand(query);
                cmd.Connection = connection;
                 return cmd;
             }
    }
}
