﻿namespace ShopDBConnection
{
    partial class Manage_Customer
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ManageCustomerGroupBox = new System.Windows.Forms.GroupBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.SecurityAnswerTextBox = new System.Windows.Forms.TextBox();
            this.SecurityAnswerLabel = new System.Windows.Forms.Label();
            this.SecurityQuestionTextBox = new System.Windows.Forms.TextBox();
            this.SecurityQuestionLevel = new System.Windows.Forms.Label();
            this.UpdateCustomeButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.ManageCustomerDataGridView = new System.Windows.Forms.DataGridView();
            this.DeleteAdminButton = new System.Windows.Forms.Button();
            this.GenderFemaleRadioButton = new System.Windows.Forms.RadioButton();
            this.GenderMaleRadioButton = new System.Windows.Forms.RadioButton();
            this.GenderLabel = new System.Windows.Forms.Label();
            this.AgeTextBox = new System.Windows.Forms.TextBox();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.AgeLabel = new System.Windows.Forms.Label();
            this.InsertCustomerButton = new System.Windows.Forms.Button();
            this.AddressTextBox = new System.Windows.Forms.TextBox();
            this.PhoneNoTextBox = new System.Windows.Forms.TextBox();
            this.Addresslabel = new System.Windows.Forms.Label();
            this.PhoneNoLabel = new System.Windows.Forms.Label();
            this.ManageCustomerGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ManageCustomerDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ManageCustomerGroupBox
            // 
            this.ManageCustomerGroupBox.Controls.Add(this.PasswordLabel);
            this.ManageCustomerGroupBox.Controls.Add(this.PasswordTextBox);
            this.ManageCustomerGroupBox.Controls.Add(this.SecurityAnswerTextBox);
            this.ManageCustomerGroupBox.Controls.Add(this.SecurityAnswerLabel);
            this.ManageCustomerGroupBox.Controls.Add(this.SecurityQuestionTextBox);
            this.ManageCustomerGroupBox.Controls.Add(this.SecurityQuestionLevel);
            this.ManageCustomerGroupBox.Controls.Add(this.UpdateCustomeButton);
            this.ManageCustomerGroupBox.Controls.Add(this.BackButton);
            this.ManageCustomerGroupBox.Controls.Add(this.ManageCustomerDataGridView);
            this.ManageCustomerGroupBox.Controls.Add(this.DeleteAdminButton);
            this.ManageCustomerGroupBox.Controls.Add(this.GenderFemaleRadioButton);
            this.ManageCustomerGroupBox.Controls.Add(this.GenderMaleRadioButton);
            this.ManageCustomerGroupBox.Controls.Add(this.GenderLabel);
            this.ManageCustomerGroupBox.Controls.Add(this.AgeTextBox);
            this.ManageCustomerGroupBox.Controls.Add(this.NameTextBox);
            this.ManageCustomerGroupBox.Controls.Add(this.NameLabel);
            this.ManageCustomerGroupBox.Controls.Add(this.AgeLabel);
            this.ManageCustomerGroupBox.Controls.Add(this.InsertCustomerButton);
            this.ManageCustomerGroupBox.Controls.Add(this.AddressTextBox);
            this.ManageCustomerGroupBox.Controls.Add(this.PhoneNoTextBox);
            this.ManageCustomerGroupBox.Controls.Add(this.Addresslabel);
            this.ManageCustomerGroupBox.Controls.Add(this.PhoneNoLabel);
            this.ManageCustomerGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.ManageCustomerGroupBox.Location = new System.Drawing.Point(80, 35);
            this.ManageCustomerGroupBox.Name = "ManageCustomerGroupBox";
            this.ManageCustomerGroupBox.Size = new System.Drawing.Size(805, 628);
            this.ManageCustomerGroupBox.TabIndex = 46;
            this.ManageCustomerGroupBox.TabStop = false;
            this.ManageCustomerGroupBox.Text = "Manage Customer";
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordLabel.Location = new System.Drawing.Point(419, 173);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(106, 25);
            this.PasswordLabel.TabIndex = 61;
            this.PasswordLabel.Text = "Password";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordTextBox.Location = new System.Drawing.Point(531, 166);
            this.PasswordTextBox.Multiline = true;
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(228, 34);
            this.PasswordTextBox.TabIndex = 60;
            // 
            // SecurityAnswerTextBox
            // 
            this.SecurityAnswerTextBox.Location = new System.Drawing.Point(559, 110);
            this.SecurityAnswerTextBox.Multiline = true;
            this.SecurityAnswerTextBox.Name = "SecurityAnswerTextBox";
            this.SecurityAnswerTextBox.Size = new System.Drawing.Size(200, 33);
            this.SecurityAnswerTextBox.TabIndex = 59;
            // 
            // SecurityAnswerLabel
            // 
            this.SecurityAnswerLabel.AutoSize = true;
            this.SecurityAnswerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecurityAnswerLabel.Location = new System.Drawing.Point(379, 114);
            this.SecurityAnswerLabel.Name = "SecurityAnswerLabel";
            this.SecurityAnswerLabel.Size = new System.Drawing.Size(154, 25);
            this.SecurityAnswerLabel.TabIndex = 58;
            this.SecurityAnswerLabel.Text = "Security Answer";
            // 
            // SecurityQuestionTextBox
            // 
            this.SecurityQuestionTextBox.Location = new System.Drawing.Point(538, 52);
            this.SecurityQuestionTextBox.Multiline = true;
            this.SecurityQuestionTextBox.Name = "SecurityQuestionTextBox";
            this.SecurityQuestionTextBox.ReadOnly = true;
            this.SecurityQuestionTextBox.Size = new System.Drawing.Size(221, 33);
            this.SecurityQuestionTextBox.TabIndex = 57;
            this.SecurityQuestionTextBox.Text = "what\'s your 1st pet name? ";
            // 
            // SecurityQuestionLevel
            // 
            this.SecurityQuestionLevel.AutoSize = true;
            this.SecurityQuestionLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecurityQuestionLevel.Location = new System.Drawing.Point(370, 60);
            this.SecurityQuestionLevel.Name = "SecurityQuestionLevel";
            this.SecurityQuestionLevel.Size = new System.Drawing.Size(162, 25);
            this.SecurityQuestionLevel.TabIndex = 56;
            this.SecurityQuestionLevel.Text = "Security question";
            // 
            // UpdateCustomeButton
            // 
            this.UpdateCustomeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateCustomeButton.Location = new System.Drawing.Point(240, 342);
            this.UpdateCustomeButton.Name = "UpdateCustomeButton";
            this.UpdateCustomeButton.Size = new System.Drawing.Size(163, 42);
            this.UpdateCustomeButton.TabIndex = 48;
            this.UpdateCustomeButton.Text = "Update Customer";
            this.UpdateCustomeButton.UseVisualStyleBackColor = true;
            this.UpdateCustomeButton.Click += new System.EventHandler(this.UpdateCustomeButton_Click);
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(681, 343);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 46;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ManageCustomerDataGridView
            // 
            this.ManageCustomerDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ManageCustomerDataGridView.Location = new System.Drawing.Point(48, 391);
            this.ManageCustomerDataGridView.Name = "ManageCustomerDataGridView";
            this.ManageCustomerDataGridView.RowHeadersWidth = 51;
            this.ManageCustomerDataGridView.RowTemplate.Height = 24;
            this.ManageCustomerDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ManageCustomerDataGridView.Size = new System.Drawing.Size(720, 214);
            this.ManageCustomerDataGridView.TabIndex = 47;
            this.ManageCustomerDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ManageCustomerDataGridView_CellClick);
            // 
            // DeleteAdminButton
            // 
            this.DeleteAdminButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteAdminButton.Location = new System.Drawing.Point(436, 343);
            this.DeleteAdminButton.Name = "DeleteAdminButton";
            this.DeleteAdminButton.Size = new System.Drawing.Size(163, 42);
            this.DeleteAdminButton.TabIndex = 46;
            this.DeleteAdminButton.Text = "Delete Customer";
            this.DeleteAdminButton.UseVisualStyleBackColor = true;
            this.DeleteAdminButton.Click += new System.EventHandler(this.DeleteAdminButton_Click);
            // 
            // GenderFemaleRadioButton
            // 
            this.GenderFemaleRadioButton.AutoSize = true;
            this.GenderFemaleRadioButton.Location = new System.Drawing.Point(227, 271);
            this.GenderFemaleRadioButton.Name = "GenderFemaleRadioButton";
            this.GenderFemaleRadioButton.Size = new System.Drawing.Size(85, 24);
            this.GenderFemaleRadioButton.TabIndex = 45;
            this.GenderFemaleRadioButton.TabStop = true;
            this.GenderFemaleRadioButton.Text = "Female";
            this.GenderFemaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // GenderMaleRadioButton
            // 
            this.GenderMaleRadioButton.AutoSize = true;
            this.GenderMaleRadioButton.Location = new System.Drawing.Point(140, 271);
            this.GenderMaleRadioButton.Name = "GenderMaleRadioButton";
            this.GenderMaleRadioButton.Size = new System.Drawing.Size(66, 24);
            this.GenderMaleRadioButton.TabIndex = 44;
            this.GenderMaleRadioButton.TabStop = true;
            this.GenderMaleRadioButton.Text = "Male";
            this.GenderMaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderLabel.Location = new System.Drawing.Point(48, 267);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(77, 25);
            this.GenderLabel.TabIndex = 43;
            this.GenderLabel.Text = "Gender";
            // 
            // AgeTextBox
            // 
            this.AgeTextBox.Location = new System.Drawing.Point(140, 211);
            this.AgeTextBox.Multiline = true;
            this.AgeTextBox.Name = "AgeTextBox";
            this.AgeTextBox.Size = new System.Drawing.Size(200, 33);
            this.AgeTextBox.TabIndex = 42;
            this.AgeTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AgeTextBox_KeyPress);
            // 
            // NameTextBox
            // 
            this.NameTextBox.Location = new System.Drawing.Point(137, 51);
            this.NameTextBox.Multiline = true;
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(200, 33);
            this.NameTextBox.TabIndex = 41;
            this.NameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NameTextBox_KeyPress);
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameLabel.Location = new System.Drawing.Point(56, 60);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(64, 25);
            this.NameLabel.TabIndex = 40;
            this.NameLabel.Text = "Name";
            // 
            // AgeLabel
            // 
            this.AgeLabel.AutoSize = true;
            this.AgeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgeLabel.Location = new System.Drawing.Point(72, 219);
            this.AgeLabel.Name = "AgeLabel";
            this.AgeLabel.Size = new System.Drawing.Size(48, 25);
            this.AgeLabel.TabIndex = 39;
            this.AgeLabel.Text = "Age";
            // 
            // InsertCustomerButton
            // 
            this.InsertCustomerButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertCustomerButton.Location = new System.Drawing.Point(65, 343);
            this.InsertCustomerButton.Name = "InsertCustomerButton";
            this.InsertCustomerButton.Size = new System.Drawing.Size(163, 42);
            this.InsertCustomerButton.TabIndex = 38;
            this.InsertCustomerButton.Text = "Insert Customer";
            this.InsertCustomerButton.UseVisualStyleBackColor = true;
            this.InsertCustomerButton.Click += new System.EventHandler(this.InsertCustomerButton_Click);
            // 
            // AddressTextBox
            // 
            this.AddressTextBox.Location = new System.Drawing.Point(137, 159);
            this.AddressTextBox.Multiline = true;
            this.AddressTextBox.Name = "AddressTextBox";
            this.AddressTextBox.Size = new System.Drawing.Size(200, 33);
            this.AddressTextBox.TabIndex = 3;
            this.AddressTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AddressTextBox_KeyPress);
            // 
            // PhoneNoTextBox
            // 
            this.PhoneNoTextBox.Location = new System.Drawing.Point(137, 110);
            this.PhoneNoTextBox.Multiline = true;
            this.PhoneNoTextBox.Name = "PhoneNoTextBox";
            this.PhoneNoTextBox.Size = new System.Drawing.Size(200, 33);
            this.PhoneNoTextBox.TabIndex = 2;
            this.PhoneNoTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PhoneNoTextBox_KeyPress);
            // 
            // Addresslabel
            // 
            this.Addresslabel.AutoSize = true;
            this.Addresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Addresslabel.Location = new System.Drawing.Point(40, 165);
            this.Addresslabel.Name = "Addresslabel";
            this.Addresslabel.Size = new System.Drawing.Size(85, 25);
            this.Addresslabel.TabIndex = 1;
            this.Addresslabel.Text = "Address";
            // 
            // PhoneNoLabel
            // 
            this.PhoneNoLabel.AutoSize = true;
            this.PhoneNoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNoLabel.Location = new System.Drawing.Point(26, 114);
            this.PhoneNoLabel.Name = "PhoneNoLabel";
            this.PhoneNoLabel.Size = new System.Drawing.Size(99, 25);
            this.PhoneNoLabel.TabIndex = 0;
            this.PhoneNoLabel.Text = "Phone No";
            // 
            // Manage_Customer
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.ManageCustomerGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Manage_Customer";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manage_Customer";
            this.Load += new System.EventHandler(this.Manage_Customer_Load);
            this.ManageCustomerGroupBox.ResumeLayout(false);
            this.ManageCustomerGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ManageCustomerDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ManageCustomerGroupBox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.DataGridView ManageCustomerDataGridView;
        private System.Windows.Forms.Button DeleteAdminButton;
        private System.Windows.Forms.RadioButton GenderFemaleRadioButton;
        private System.Windows.Forms.RadioButton GenderMaleRadioButton;
        private System.Windows.Forms.Label GenderLabel;
        private System.Windows.Forms.TextBox AgeTextBox;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Label AgeLabel;
        private System.Windows.Forms.Button InsertCustomerButton;
        private System.Windows.Forms.TextBox AddressTextBox;
        private System.Windows.Forms.TextBox PhoneNoTextBox;
        private System.Windows.Forms.Label Addresslabel;
        private System.Windows.Forms.Label PhoneNoLabel;
        private System.Windows.Forms.Button UpdateCustomeButton;
        private System.Windows.Forms.TextBox SecurityAnswerTextBox;
        private System.Windows.Forms.Label SecurityAnswerLabel;
        private System.Windows.Forms.TextBox SecurityQuestionTextBox;
        private System.Windows.Forms.Label SecurityQuestionLevel;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.TextBox PasswordTextBox;
    }
}