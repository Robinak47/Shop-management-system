﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Customer_Product : Form
    {
        User u;
        public Customer_Product(User user)
        {
            u = user;
            InitializeComponent();
        }

        private void Customer_Product_Load(object sender, EventArgs e)
        {
            Product_Data a = new Product_Data();
            CustomerProductDataGridView.DataSource = a.GetProductList();
        }

        private void CustomerProductDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Home a = new Customer_Home(u);
            a.Show();
        }
    }
}
