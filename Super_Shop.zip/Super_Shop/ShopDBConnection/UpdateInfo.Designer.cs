﻿namespace ShopDBConnection
{
    partial class UpdateInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UpdateInfoGroupbox = new System.Windows.Forms.GroupBox();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.IdTextBox = new System.Windows.Forms.TextBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.IdLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.USubmitButton = new System.Windows.Forms.Button();
            this.PhoneNotextBox1 = new System.Windows.Forms.TextBox();
            this.phoneNoLabel = new System.Windows.Forms.Label();
            this.UpdateInfoGroupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // UpdateInfoGroupbox
            // 
            this.UpdateInfoGroupbox.Controls.Add(this.PasswordTextBox);
            this.UpdateInfoGroupbox.Controls.Add(this.IdTextBox);
            this.UpdateInfoGroupbox.Controls.Add(this.PasswordLabel);
            this.UpdateInfoGroupbox.Controls.Add(this.IdLabel);
            this.UpdateInfoGroupbox.Controls.Add(this.BackButton);
            this.UpdateInfoGroupbox.Controls.Add(this.USubmitButton);
            this.UpdateInfoGroupbox.Controls.Add(this.PhoneNotextBox1);
            this.UpdateInfoGroupbox.Controls.Add(this.phoneNoLabel);
            this.UpdateInfoGroupbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateInfoGroupbox.Location = new System.Drawing.Point(121, 77);
            this.UpdateInfoGroupbox.Name = "UpdateInfoGroupbox";
            this.UpdateInfoGroupbox.Size = new System.Drawing.Size(722, 547);
            this.UpdateInfoGroupbox.TabIndex = 44;
            this.UpdateInfoGroupbox.TabStop = false;
            this.UpdateInfoGroupbox.Text = "Update Info";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(312, 278);
            this.PasswordTextBox.Multiline = true;
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(200, 33);
            this.PasswordTextBox.TabIndex = 43;
            this.PasswordTextBox.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // IdTextBox
            // 
            this.IdTextBox.Location = new System.Drawing.Point(312, 136);
            this.IdTextBox.Multiline = true;
            this.IdTextBox.Name = "IdTextBox";
            this.IdTextBox.Size = new System.Drawing.Size(200, 33);
            this.IdTextBox.TabIndex = 42;
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordLabel.Location = new System.Drawing.Point(190, 278);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(98, 25);
            this.PasswordLabel.TabIndex = 41;
            this.PasswordLabel.Text = "Password";
            // 
            // IdLabel
            // 
            this.IdLabel.AutoSize = true;
            this.IdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdLabel.Location = new System.Drawing.Point(183, 144);
            this.IdLabel.Name = "IdLabel";
            this.IdLabel.Size = new System.Drawing.Size(28, 25);
            this.IdLabel.TabIndex = 40;
            this.IdLabel.Text = "Id";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(434, 432);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 39;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // USubmitButton
            // 
            this.USubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.USubmitButton.Location = new System.Drawing.Point(312, 432);
            this.USubmitButton.Name = "USubmitButton";
            this.USubmitButton.Size = new System.Drawing.Size(87, 41);
            this.USubmitButton.TabIndex = 38;
            this.USubmitButton.Text = "Submit";
            this.USubmitButton.UseVisualStyleBackColor = true;
            this.USubmitButton.Click += new System.EventHandler(this.USubmitButton_Click);
            // 
            // PhoneNotextBox1
            // 
            this.PhoneNotextBox1.Location = new System.Drawing.Point(312, 209);
            this.PhoneNotextBox1.Multiline = true;
            this.PhoneNotextBox1.Name = "PhoneNotextBox1";
            this.PhoneNotextBox1.Size = new System.Drawing.Size(200, 33);
            this.PhoneNotextBox1.TabIndex = 2;
            this.PhoneNotextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PhoneNotextBox1_KeyPress);
            // 
            // phoneNoLabel
            // 
            this.phoneNoLabel.AutoSize = true;
            this.phoneNoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNoLabel.Location = new System.Drawing.Point(183, 209);
            this.phoneNoLabel.Name = "phoneNoLabel";
            this.phoneNoLabel.Size = new System.Drawing.Size(99, 25);
            this.phoneNoLabel.TabIndex = 0;
            this.phoneNoLabel.Text = "Phone No";
            // 
            // UpdateInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.UpdateInfoGroupbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "UpdateInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "UpdateInfo";
            this.Load += new System.EventHandler(this.UpdateInfo_Load);
            this.UpdateInfoGroupbox.ResumeLayout(false);
            this.UpdateInfoGroupbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox UpdateInfoGroupbox;
        private System.Windows.Forms.Button USubmitButton;
        private System.Windows.Forms.TextBox PhoneNotextBox1;
        private System.Windows.Forms.Label phoneNoLabel;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.TextBox IdTextBox;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.Label IdLabel;
    }
}