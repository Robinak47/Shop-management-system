﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopDBConnection
{
    public partial class Employee_Home : Form
    {
        public Employee_Home()
        {
            InitializeComponent();
        }

        private void UpdateSelfInfoButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Employee_UpdateInfo a = new Employee_UpdateInfo();
            a.Show();
        }

        private void ChangePasswordButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Employee_Change_Password a = new Employee_Change_Password();
            a.Show();
        }

        private void AddProductButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Manage_Product a = new Manage_Product();
            a.Show();
        }

        private void AddCustomerButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Manage_Customer a = new Manage_Customer();
            a.Show();
        }

        private void CreateBillButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Create_Bill a = new Create_Bill();
            a.Show();
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login_Form a = new Login_Form();
            a.Show();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        
    }
}
