﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Bill : Form
    {
        public Bill()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin a = new Admin();
            a.Show();
        }

        private void Bill_Load(object sender, EventArgs e)
        {
            Order_Data a = new Order_Data();
            BillDataGridView.DataSource = a.GetOrderList();

        }

        private void BillDataGridView_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
