﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class UpdateInfo : Form
    {
        public UpdateInfo()
        {
            InitializeComponent();
            PhoneNotextBox1.MaxLength = 11;
        }

        private void PhoneNotextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

     

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin a=new Admin();
            a.Show();
        }

        private void UpdateInfo_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void USubmitButton_Click(object sender, EventArgs e)
        {
            if ((IdTextBox.Text != "") && PasswordTextBox.Text != "")
            {
                if (PhoneNotextBox1.Text != "")
                {
                    try
                    {
                        User user = new User();
                        LoginData a = new LoginData();
                        user = a.getuser(IdTextBox.Text, PasswordTextBox.Text);
                        if (user.UserId == IdTextBox.Text)
                        {
                            Admin_Data x = new Admin_Data();
                            x.UpdateAdmin(IdTextBox.Text, Convert.ToInt32(PhoneNotextBox1.Text));
                            MessageBox.Show("updated", "done", MessageBoxButtons.OK);
                            IdTextBox.Clear();
                            PasswordTextBox.Clear();
                            PhoneNotextBox1.Clear();

                        }
                        else
                        {
                            MessageBox.Show("wrong id or password", "failed", MessageBoxButtons.OK);
                            IdTextBox.Clear();
                            PasswordTextBox.Clear();
                            PhoneNotextBox1.Clear();
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("exception", "failed", MessageBoxButtons.OK);
                        IdTextBox.Clear();
                        PasswordTextBox.Clear();
                        PhoneNotextBox1.Clear();
                    }
                }

                else
                {
                    MessageBox.Show("please fill all field", "failed", MessageBoxButtons.OK);
                    IdTextBox.Clear();
                    PasswordTextBox.Clear();
                    PhoneNotextBox1.Clear();
                }
            }
            else
            {
                MessageBox.Show("please fill all field", "failed", MessageBoxButtons.OK);
                IdTextBox.Clear();
                PasswordTextBox.Clear();
                PhoneNotextBox1.Clear();
            }
        }
    }
}
