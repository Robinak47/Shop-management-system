﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Create_Bill : Form
    {
        private string Rid = createId();
        private string pid;
        private string Id;
        private int track;
        private int tp;
        int total_ammount = 0;
        public Create_Bill()
        {
            InitializeComponent();
            CustomerIdTextBox.MaxLength = 50;
            ProductIdTextBox.MaxLength = 50;
            QuantityTextBox.MaxLength = 10;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Employee_Home a = new Employee_Home();
            a.Show();
        }

        private void QuantityTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void CartButton_Click(object sender, EventArgs e)
        {
            if ((CustomerIdTextBox.Text != "") && (ProductIdTextBox.Text != ""))
            {
                if ((QuantityTextBox.Text) != "")
                {
                    try
                    {
                        CustomerD m;
                        Customer_Data z = new Customer_Data();
                        m = z.getCustomer(CustomerIdTextBox.Text);
                        ProductD d;
                        Product_Data v = new Product_Data();
                        d = v.getProduct(ProductIdTextBox.Text);

                        if ((m.Customer_Id == CustomerIdTextBox.Text) && (d.Product_Id == ProductIdTextBox.Text) && (d.Product_Status == "active"))
                        {

                            if (pid != ProductIdTextBox.Text)
                            {
                                Order_LineD o = new Order_LineD();
                                o.Order_Id = Rid;
                                String zz = o.Order_Id;
                                o.Product_Id = ProductIdTextBox.Text;
                                pid = o.Product_Id;
                                o.Quantity = Convert.ToInt32(QuantityTextBox.Text);
                                if (o.Quantity <= d.Quantity)
                                {
                                    int price = 0;
                                    price = (o.Quantity) * (d.Price);
                                    o.Price = price;
                                    total_ammount = total_ammount + price;
                                    Order_Line_Data a = new Order_Line_Data();
                                    a.InsertOrder_Line(o);
                                    Product_Data ww = new Product_Data();
                                    int newQuantity = d.Quantity - o.Quantity;
                                    ww.UpdateProduct(d.Product_Id, newQuantity, d.Price);



                                    ProductIdTextBox.Clear();
                                    QuantityTextBox.Clear();





                                    CreateBillDataGridView.DataSource = a.GetOrder_LineList(zz);
                                }

                                else
                                {
                                    MessageBox.Show("failed.please Provide Quantity", "create bill", MessageBoxButtons.OK);
                                    QuantityTextBox.Clear();

                                }








                            }
                            else
                            {
                                MessageBox.Show("failed.cannot enter same product key in same order" + m.Customer_Id + m.Customer_Status + d.Product_Id + d.Product_Status, "create bill", MessageBoxButtons.OK);
                                CustomerIdTextBox.Clear();
                                ProductIdTextBox.Clear();
                                QuantityTextBox.Clear();


                            }

                        }
                        else
                        {
                            MessageBox.Show("failed.customer or product not found.customer id" + m.Customer_Id + m.Customer_Status + d.Product_Id + d.Product_Status, "create bill", MessageBoxButtons.OK);
                            CustomerIdTextBox.Clear();
                            ProductIdTextBox.Clear();
                            QuantityTextBox.Clear();


                        }



                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Exception", "create bill", MessageBoxButtons.OK);
                        CustomerIdTextBox.Clear();
                        ProductIdTextBox.Clear();
                        QuantityTextBox.Clear();
                    }
                }
                else
                {
                    MessageBox.Show("failed.please Provide Quantity", "create bill", MessageBoxButtons.OK);
                    QuantityTextBox.Clear();



                }
            }

            else
            {
                MessageBox.Show("failed.please Provide customerId or ProductId", "create bill", MessageBoxButtons.OK);
                CustomerIdTextBox.Clear();
                ProductIdTextBox.Clear();
                QuantityTextBox.Clear();


            }
        }
        public static string createId()
        {
            Random xx = new Random();
            int y = xx.Next(0, 100000);
            string a = "R-" + y;
            return a;

        }

        private void CreateBillGroupBox_Enter(object sender, EventArgs e)
        {

        }

        private void Create_Bill_Load(object sender, EventArgs e)
        {
            

               
        }

       
        private void RemoveCurtButton_Click(object sender, EventArgs e)
        {
            if ((CustomerIdTextBox.Text != "") && (ProductIdTextBox.Text != ""))
            {
                if ((QuantityTextBox.Text) != "")
                {
                    try
                    {
                        CustomerD m = new CustomerD();
                        Customer_Data z = new Customer_Data();
                        m = z.getCustomer(CustomerIdTextBox.Text);
                        ProductD d = new ProductD();
                        Product_Data v = new Product_Data();
                        d = v.getProduct(ProductIdTextBox.Text);

                        if ((m.Customer_Id == CustomerIdTextBox.Text) && (d.Product_Id == ProductIdTextBox.Text) && (d.Product_Status == "active"))
                        {
                            Order_LineD o = new Order_LineD();
                            o.Order_Id = Id;
                            String zz = o.Order_Id;
                            o.Product_Id = ProductIdTextBox.Text;
                            o.Quantity = Convert.ToInt32(QuantityTextBox.Text);
                            Order_Line_Data a = new Order_Line_Data();
                            a.DeleteOrder_Line(Id, o.Product_Id);
                            Product_Data ww = new Product_Data();
                            int newQuantity = d.Quantity + o.Quantity;
                            int price = d.Price * o.Quantity;
                            total_ammount = total_ammount - price;
                            ww.UpdateProduct(d.Product_Id, newQuantity, d.Price);



                            ProductIdTextBox.Clear();
                            QuantityTextBox.Clear();





                            CreateBillDataGridView.DataSource = a.GetOrder_LineList(zz);
                            Id = "";








                        }
                        else
                        {
                            MessageBox.Show("failed.customer or product not found", "create bill", MessageBoxButtons.OK);

                            ProductIdTextBox.Clear();
                            QuantityTextBox.Clear();


                        }



                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Exception", "create bill", MessageBoxButtons.OK);
                        CustomerIdTextBox.Clear();
                        ProductIdTextBox.Clear();
                        QuantityTextBox.Clear();
                        Id = "";
                    }
                }
                else
                {
                    MessageBox.Show("failed.please Provide Quantity", "create bill", MessageBoxButtons.OK);
                    QuantityTextBox.Clear();



                }
            }

            else
            {
                MessageBox.Show("failed.please Provide customerId or ProductId", "create bill", MessageBoxButtons.OK);
                ProductIdTextBox.Clear();
                QuantityTextBox.Clear();


            }
        }

        private void CreateBillDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Id = CreateBillDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            ProductIdTextBox.Text = CreateBillDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            QuantityTextBox.Text = CreateBillDataGridView.SelectedRows[0].Cells[2].Value.ToString();
            tp = Convert.ToInt32(CreateBillDataGridView.SelectedRows[0].Cells[3].Value);

            track = Convert.ToInt32(QuantityTextBox.Text);
            
           TotalBillTextBox.Clear();
        }

        

        private void MakeBillButton_Click(object sender, EventArgs e)
        {
            if (total_ammount > 0)
            {
                TotalBillTextBox.Text = total_ammount.ToString();
                OrderD a = new OrderD();
                a.orderId = Rid;
                a.Customer_Id = CustomerIdTextBox.Text;
                a.Total_Amount = total_ammount;
                Order_Data x = new Order_Data();
                x.InsertOrder(a);
            }

            else
            {
                MessageBox.Show("sorry", "sorry", MessageBoxButtons.OK);
            }
        }







       
    }
}
