﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Customer_Change_Password : Form
    {
        User u;
        public Customer_Change_Password(User user)
        {
            u = user;
            InitializeComponent();
            NewPasswordTextBox.MaxLength = 20;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Home a = new Customer_Home(u);
            a.Show();
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            if ((IdTextBox.Text != "") && (NewPasswordTextBox.Text != "") && (CurrentPasswordTextBox.Text != ""))
            {
                LoginData f = new LoginData();
                string c = f.SearchPassword(IdTextBox.Text);



                if (CurrentPasswordTextBox.Text == c)
                {
                    LoginData m = new LoginData();
                    m.Update_Password(IdTextBox.Text, NewPasswordTextBox.Text);

                    MessageBox.Show("Password updated", "Password change", MessageBoxButtons.OK);
                    IdTextBox.Clear();
                    CurrentPasswordTextBox.Clear();
                    NewPasswordTextBox.Clear();
                    this.Hide();
                    Login_Form a = new Login_Form();
                    a.Show();




                }



                else if (CurrentPasswordTextBox.Text != c)
                {


                    MessageBox.Show("current password wrong", "Password change", MessageBoxButtons.OK);
                    IdTextBox.Clear();
                    CurrentPasswordTextBox.Clear();
                    NewPasswordTextBox.Clear();




                }

            }
            else
            {


                MessageBox.Show("please provide all field", "Password change", MessageBoxButtons.OK);
                IdTextBox.Clear();
                CurrentPasswordTextBox.Clear();
                NewPasswordTextBox.Clear();




            }
        }

        private void Customer_Change_Password_Load(object sender, EventArgs e)
        {

        }
    }
}
