﻿namespace ShopDBConnection
{
    partial class Add_Update_Delete__Employee
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddEmployeeGroupBox = new System.Windows.Forms.GroupBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.SecurityAnswerTextBox = new System.Windows.Forms.TextBox();
            this.SecurityAnswerLabel = new System.Windows.Forms.Label();
            this.SecurityQuestionTextBox = new System.Windows.Forms.TextBox();
            this.SecurityQuestionLevel = new System.Windows.Forms.Label();
            this.UpdateEmployeeButton = new System.Windows.Forms.Button();
            this.InsertEmployeeDataGridView = new System.Windows.Forms.DataGridView();
            this.InsertEmployeeButton = new System.Windows.Forms.Button();
            this.DesignationTextBox = new System.Windows.Forms.TextBox();
            this.SalaryLabel = new System.Windows.Forms.Label();
            this.SalaryTextBox = new System.Windows.Forms.TextBox();
            this.DesignationLabel = new System.Windows.Forms.Label();
            this.FemaleRadioButton = new System.Windows.Forms.RadioButton();
            this.GenderLabel = new System.Windows.Forms.Label();
            this.DeleteEmployeeButton = new System.Windows.Forms.Button();
            this.MaleRadioButton = new System.Windows.Forms.RadioButton();
            this.AddressLabel = new System.Windows.Forms.Label();
            this.PhoneNoTextBox = new System.Windows.Forms.TextBox();
            this.PhoneLabel = new System.Windows.Forms.Label();
            this.AddressTextBox = new System.Windows.Forms.TextBox();
            this.AgeTextBox = new System.Windows.Forms.TextBox();
            this.AgeLabel = new System.Windows.Forms.Label();
            this.NameTextBox = new System.Windows.Forms.TextBox();
            this.NameLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.AddEmployeeGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InsertEmployeeDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // AddEmployeeGroupBox
            // 
            this.AddEmployeeGroupBox.Controls.Add(this.BackButton);
            this.AddEmployeeGroupBox.Controls.Add(this.PasswordLabel);
            this.AddEmployeeGroupBox.Controls.Add(this.PasswordTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.SecurityAnswerTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.SecurityAnswerLabel);
            this.AddEmployeeGroupBox.Controls.Add(this.SecurityQuestionTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.SecurityQuestionLevel);
            this.AddEmployeeGroupBox.Controls.Add(this.UpdateEmployeeButton);
            this.AddEmployeeGroupBox.Controls.Add(this.InsertEmployeeDataGridView);
            this.AddEmployeeGroupBox.Controls.Add(this.InsertEmployeeButton);
            this.AddEmployeeGroupBox.Controls.Add(this.DesignationTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.SalaryLabel);
            this.AddEmployeeGroupBox.Controls.Add(this.SalaryTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.DesignationLabel);
            this.AddEmployeeGroupBox.Controls.Add(this.FemaleRadioButton);
            this.AddEmployeeGroupBox.Controls.Add(this.GenderLabel);
            this.AddEmployeeGroupBox.Controls.Add(this.DeleteEmployeeButton);
            this.AddEmployeeGroupBox.Controls.Add(this.MaleRadioButton);
            this.AddEmployeeGroupBox.Controls.Add(this.AddressLabel);
            this.AddEmployeeGroupBox.Controls.Add(this.PhoneNoTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.PhoneLabel);
            this.AddEmployeeGroupBox.Controls.Add(this.AddressTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.AgeTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.AgeLabel);
            this.AddEmployeeGroupBox.Controls.Add(this.NameTextBox);
            this.AddEmployeeGroupBox.Controls.Add(this.NameLabel);
            this.AddEmployeeGroupBox.Location = new System.Drawing.Point(70, 26);
            this.AddEmployeeGroupBox.Name = "AddEmployeeGroupBox";
            this.AddEmployeeGroupBox.Size = new System.Drawing.Size(773, 661);
            this.AddEmployeeGroupBox.TabIndex = 26;
            this.AddEmployeeGroupBox.TabStop = false;
            this.AddEmployeeGroupBox.Text = "Add_Update_Delete Employee";
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordLabel.Location = new System.Drawing.Point(421, 186);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(106, 25);
            this.PasswordLabel.TabIndex = 57;
            this.PasswordLabel.Text = "Password";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordTextBox.Location = new System.Drawing.Point(533, 179);
            this.PasswordTextBox.Multiline = true;
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(228, 34);
            this.PasswordTextBox.TabIndex = 56;
            // 
            // SecurityAnswerTextBox
            // 
            this.SecurityAnswerTextBox.Location = new System.Drawing.Point(209, 293);
            this.SecurityAnswerTextBox.Multiline = true;
            this.SecurityAnswerTextBox.Name = "SecurityAnswerTextBox";
            this.SecurityAnswerTextBox.Size = new System.Drawing.Size(200, 33);
            this.SecurityAnswerTextBox.TabIndex = 55;
            // 
            // SecurityAnswerLabel
            // 
            this.SecurityAnswerLabel.AutoSize = true;
            this.SecurityAnswerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecurityAnswerLabel.Location = new System.Drawing.Point(13, 293);
            this.SecurityAnswerLabel.Name = "SecurityAnswerLabel";
            this.SecurityAnswerLabel.Size = new System.Drawing.Size(154, 25);
            this.SecurityAnswerLabel.TabIndex = 54;
            this.SecurityAnswerLabel.Text = "Security Answer";
            this.SecurityAnswerLabel.Click += new System.EventHandler(this.SecurityAnswerLabel_Click);
            // 
            // SecurityQuestionTextBox
            // 
            this.SecurityQuestionTextBox.Location = new System.Drawing.Point(186, 235);
            this.SecurityQuestionTextBox.Multiline = true;
            this.SecurityQuestionTextBox.Name = "SecurityQuestionTextBox";
            this.SecurityQuestionTextBox.ReadOnly = true;
            this.SecurityQuestionTextBox.Size = new System.Drawing.Size(221, 33);
            this.SecurityQuestionTextBox.TabIndex = 53;
            this.SecurityQuestionTextBox.Text = "what\'s your 1st pet name? ";
            // 
            // SecurityQuestionLevel
            // 
            this.SecurityQuestionLevel.AutoSize = true;
            this.SecurityQuestionLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecurityQuestionLevel.Location = new System.Drawing.Point(8, 243);
            this.SecurityQuestionLevel.Name = "SecurityQuestionLevel";
            this.SecurityQuestionLevel.Size = new System.Drawing.Size(162, 25);
            this.SecurityQuestionLevel.TabIndex = 52;
            this.SecurityQuestionLevel.Text = "Security question";
            this.SecurityQuestionLevel.Click += new System.EventHandler(this.SecurityQuestionLevel_Click);
            // 
            // UpdateEmployeeButton
            // 
            this.UpdateEmployeeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateEmployeeButton.Location = new System.Drawing.Point(246, 350);
            this.UpdateEmployeeButton.Name = "UpdateEmployeeButton";
            this.UpdateEmployeeButton.Size = new System.Drawing.Size(163, 41);
            this.UpdateEmployeeButton.TabIndex = 39;
            this.UpdateEmployeeButton.Text = "Update Employee";
            this.UpdateEmployeeButton.UseVisualStyleBackColor = true;
            this.UpdateEmployeeButton.Click += new System.EventHandler(this.UpdateEmployeeButton_Click);
            // 
            // InsertEmployeeDataGridView
            // 
            this.InsertEmployeeDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.InsertEmployeeDataGridView.Location = new System.Drawing.Point(13, 415);
            this.InsertEmployeeDataGridView.Name = "InsertEmployeeDataGridView";
            this.InsertEmployeeDataGridView.RowHeadersWidth = 51;
            this.InsertEmployeeDataGridView.RowTemplate.Height = 24;
            this.InsertEmployeeDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.InsertEmployeeDataGridView.Size = new System.Drawing.Size(744, 225);
            this.InsertEmployeeDataGridView.TabIndex = 38;
            this.InsertEmployeeDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.InsertEmployeeDataGridView_CellClick);
            // 
            // InsertEmployeeButton
            // 
            this.InsertEmployeeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertEmployeeButton.Location = new System.Drawing.Point(18, 350);
            this.InsertEmployeeButton.Name = "InsertEmployeeButton";
            this.InsertEmployeeButton.Size = new System.Drawing.Size(163, 41);
            this.InsertEmployeeButton.TabIndex = 33;
            this.InsertEmployeeButton.Text = "Add Employee";
            this.InsertEmployeeButton.UseVisualStyleBackColor = true;
            this.InsertEmployeeButton.Click += new System.EventHandler(this.InsertEmployeeButton_Click);
            // 
            // DesignationTextBox
            // 
            this.DesignationTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DesignationTextBox.Location = new System.Drawing.Point(180, 179);
            this.DesignationTextBox.Multiline = true;
            this.DesignationTextBox.Name = "DesignationTextBox";
            this.DesignationTextBox.Size = new System.Drawing.Size(228, 34);
            this.DesignationTextBox.TabIndex = 32;
            this.DesignationTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.DesignationTextBox_KeyPress);
            // 
            // SalaryLabel
            // 
            this.SalaryLabel.AutoSize = true;
            this.SalaryLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryLabel.Location = new System.Drawing.Point(424, 132);
            this.SalaryLabel.Name = "SalaryLabel";
            this.SalaryLabel.Size = new System.Drawing.Size(74, 25);
            this.SalaryLabel.TabIndex = 31;
            this.SalaryLabel.Text = "Salary";
            // 
            // SalaryTextBox
            // 
            this.SalaryTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SalaryTextBox.Location = new System.Drawing.Point(529, 123);
            this.SalaryTextBox.Multiline = true;
            this.SalaryTextBox.Name = "SalaryTextBox";
            this.SalaryTextBox.Size = new System.Drawing.Size(228, 34);
            this.SalaryTextBox.TabIndex = 30;
            this.SalaryTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SalaryTextBox_KeyPress);
            // 
            // DesignationLabel
            // 
            this.DesignationLabel.AutoSize = true;
            this.DesignationLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DesignationLabel.Location = new System.Drawing.Point(7, 186);
            this.DesignationLabel.Name = "DesignationLabel";
            this.DesignationLabel.Size = new System.Drawing.Size(126, 25);
            this.DesignationLabel.TabIndex = 29;
            this.DesignationLabel.Text = "Designation";
            // 
            // FemaleRadioButton
            // 
            this.FemaleRadioButton.AutoSize = true;
            this.FemaleRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FemaleRadioButton.Location = new System.Drawing.Point(666, 78);
            this.FemaleRadioButton.Name = "FemaleRadioButton";
            this.FemaleRadioButton.Size = new System.Drawing.Size(91, 24);
            this.FemaleRadioButton.TabIndex = 28;
            this.FemaleRadioButton.TabStop = true;
            this.FemaleRadioButton.Text = "Female";
            this.FemaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // GenderLabel
            // 
            this.GenderLabel.AutoSize = true;
            this.GenderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.GenderLabel.Location = new System.Drawing.Point(421, 78);
            this.GenderLabel.Name = "GenderLabel";
            this.GenderLabel.Size = new System.Drawing.Size(83, 25);
            this.GenderLabel.TabIndex = 27;
            this.GenderLabel.Text = "Gender";
            // 
            // DeleteEmployeeButton
            // 
            this.DeleteEmployeeButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteEmployeeButton.Location = new System.Drawing.Point(465, 348);
            this.DeleteEmployeeButton.Name = "DeleteEmployeeButton";
            this.DeleteEmployeeButton.Size = new System.Drawing.Size(163, 43);
            this.DeleteEmployeeButton.TabIndex = 21;
            this.DeleteEmployeeButton.Text = "Delete Emloyee";
            this.DeleteEmployeeButton.UseVisualStyleBackColor = true;
            this.DeleteEmployeeButton.Click += new System.EventHandler(this.DeleteEmployeeButton_Click);
            // 
            // MaleRadioButton
            // 
            this.MaleRadioButton.AutoSize = true;
            this.MaleRadioButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MaleRadioButton.Location = new System.Drawing.Point(536, 80);
            this.MaleRadioButton.Name = "MaleRadioButton";
            this.MaleRadioButton.Size = new System.Drawing.Size(70, 24);
            this.MaleRadioButton.TabIndex = 26;
            this.MaleRadioButton.TabStop = true;
            this.MaleRadioButton.Text = "Male";
            this.MaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // AddressLabel
            // 
            this.AddressLabel.AutoSize = true;
            this.AddressLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressLabel.Location = new System.Drawing.Point(8, 68);
            this.AddressLabel.Name = "AddressLabel";
            this.AddressLabel.Size = new System.Drawing.Size(92, 25);
            this.AddressLabel.TabIndex = 25;
            this.AddressLabel.Text = "Address";
            // 
            // PhoneNoTextBox
            // 
            this.PhoneNoTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneNoTextBox.Location = new System.Drawing.Point(174, 123);
            this.PhoneNoTextBox.Multiline = true;
            this.PhoneNoTextBox.Name = "PhoneNoTextBox";
            this.PhoneNoTextBox.Size = new System.Drawing.Size(228, 34);
            this.PhoneNoTextBox.TabIndex = 24;
            this.PhoneNoTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PhoneNoTextBox_KeyPress);
            // 
            // PhoneLabel
            // 
            this.PhoneLabel.AutoSize = true;
            this.PhoneLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PhoneLabel.Location = new System.Drawing.Point(8, 129);
            this.PhoneLabel.Name = "PhoneLabel";
            this.PhoneLabel.Size = new System.Drawing.Size(114, 25);
            this.PhoneLabel.TabIndex = 23;
            this.PhoneLabel.Text = "Phone No:";
            // 
            // AddressTextBox
            // 
            this.AddressTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddressTextBox.Location = new System.Drawing.Point(171, 68);
            this.AddressTextBox.Multiline = true;
            this.AddressTextBox.Name = "AddressTextBox";
            this.AddressTextBox.Size = new System.Drawing.Size(228, 34);
            this.AddressTextBox.TabIndex = 22;
            this.AddressTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AddressTextBox_KeyPress);
            // 
            // AgeTextBox
            // 
            this.AgeTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgeTextBox.Location = new System.Drawing.Point(532, 22);
            this.AgeTextBox.Multiline = true;
            this.AgeTextBox.Name = "AgeTextBox";
            this.AgeTextBox.Size = new System.Drawing.Size(228, 34);
            this.AgeTextBox.TabIndex = 21;
            this.AgeTextBox.TextChanged += new System.EventHandler(this.AgeTextBox_TextChanged);
            this.AgeTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AgeTextBox_KeyPress);
            // 
            // AgeLabel
            // 
            this.AgeLabel.AutoSize = true;
            this.AgeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AgeLabel.Location = new System.Drawing.Point(424, 31);
            this.AgeLabel.Name = "AgeLabel";
            this.AgeLabel.Size = new System.Drawing.Size(51, 25);
            this.AgeLabel.TabIndex = 20;
            this.AgeLabel.Text = "Age";
            // 
            // NameTextBox
            // 
            this.NameTextBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameTextBox.Location = new System.Drawing.Point(172, 19);
            this.NameTextBox.Multiline = true;
            this.NameTextBox.Name = "NameTextBox";
            this.NameTextBox.Size = new System.Drawing.Size(228, 33);
            this.NameTextBox.TabIndex = 19;
            this.NameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.NameTextBox_KeyPress);
            // 
            // NameLabel
            // 
            this.NameLabel.AutoSize = true;
            this.NameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.NameLabel.Location = new System.Drawing.Point(25, 19);
            this.NameLabel.Name = "NameLabel";
            this.NameLabel.Size = new System.Drawing.Size(68, 25);
            this.NameLabel.TabIndex = 18;
            this.NameLabel.Text = "Name";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(666, 348);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 41;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // Add_Update_Delete__Employee
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.AddEmployeeGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Add_Update_Delete__Employee";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Add_Update_Delete__Employee";
            this.Load += new System.EventHandler(this.Add_Update_Delete__Employee_Load);
            this.AddEmployeeGroupBox.ResumeLayout(false);
            this.AddEmployeeGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.InsertEmployeeDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox AddEmployeeGroupBox;
        private System.Windows.Forms.Button UpdateEmployeeButton;
        private System.Windows.Forms.DataGridView InsertEmployeeDataGridView;
        private System.Windows.Forms.Button InsertEmployeeButton;
        private System.Windows.Forms.TextBox DesignationTextBox;
        private System.Windows.Forms.Label SalaryLabel;
        private System.Windows.Forms.TextBox SalaryTextBox;
        private System.Windows.Forms.Label DesignationLabel;
        private System.Windows.Forms.RadioButton FemaleRadioButton;
        private System.Windows.Forms.Label GenderLabel;
        private System.Windows.Forms.Button DeleteEmployeeButton;
        private System.Windows.Forms.RadioButton MaleRadioButton;
        private System.Windows.Forms.Label AddressLabel;
        private System.Windows.Forms.TextBox PhoneNoTextBox;
        private System.Windows.Forms.Label PhoneLabel;
        private System.Windows.Forms.TextBox AddressTextBox;
        private System.Windows.Forms.TextBox AgeTextBox;
        private System.Windows.Forms.Label AgeLabel;
        private System.Windows.Forms.TextBox NameTextBox;
        private System.Windows.Forms.Label NameLabel;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.TextBox SecurityAnswerTextBox;
        private System.Windows.Forms.Label SecurityAnswerLabel;
        private System.Windows.Forms.TextBox SecurityQuestionTextBox;
        private System.Windows.Forms.Label SecurityQuestionLevel;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.TextBox PasswordTextBox;
    }
}