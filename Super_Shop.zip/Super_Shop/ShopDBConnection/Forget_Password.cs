﻿using System;
using System.Collections.Generic;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Forget_Password : Form
    {
        public Forget_Password()
        {
            InitializeComponent();
        }

        private void SubmitButton_Click(object sender, EventArgs e)
        {
            if ((IdTextBox.Text != "") && (SecurityAnswerTextBox.Text != ""))
            {
                LoginData a = new LoginData();
                User u = a.finduser(IdTextBox.Text, SecurityAnswerTextBox.Text);
                if ((NewPasswordTextBox.Text == ConfirmPasswordTextBox.Text) && (u.UserId == IdTextBox.Text))
                {

                    a.Update_Password(IdTextBox.Text, NewPasswordTextBox.Text);
                    MessageBox.Show("done", "done", MessageBoxButtons.OK);
                }
                else
                {
                    MessageBox.Show("invalid id or answer", "faild", MessageBoxButtons.OK);
                }


            }
            else
            {

                MessageBox.Show("please Provide all feild", "faild", MessageBoxButtons.OK);
            }
        }

        private void Forget_Password_Load(object sender, System.EventArgs e)
        {

        }

        private void BackButton_Click(object sender, System.EventArgs e)
        {
            this.Hide();
            Login_Form a = new Login_Form();
            a.Show();
        }

        private void ExitButton_Click(object sender, System.EventArgs e)
        {
            Application.Exit();
        }
    }
}
