﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class AddAdmin : Form
    {
       
        private string Id; 

        public AddAdmin()
        {
            InitializeComponent();
            AdminNameTextBox.MaxLength = 50;
            AdminAddressTextBox.MaxLength = 50;
            AdminAgeTextBox.MaxLength = 3;
            AdminPhoneNoTextBox.MaxLength = 11;
            SecurityAnswerTextBox.MaxLength = 50;
            PasswordTextBox.MaxLength = 50;

        }

        private void AdminNameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void AdminPhoneNoTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void AdminAddressTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void AdminAgeTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin a = new Admin();
            a.Show();
        }

        private void SecurityAnswerTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void InsertAdminButton_Click(object sender, EventArgs e)
        {

            if ((AdminNameTextBox.Text !="") && (AdminPhoneNoTextBox.Text != ""))
            {
                if ((AdminAddressTextBox.Text) != "" && (AdminAgeTextBox.Text != ""))
                {
                    if ((AdminGenderMaleRadioButton.Checked) || (AdminGenderFemaleRadioButton.Checked))
                    {
                        if ((SecurityAnswerTextBox.Text) != "" && (PasswordTextBox.Text != ""))
                        {
                            AdminD o = new AdminD();
                            o.Admin_Id = createId();
                            o.Admin_Name = AdminNameTextBox.Text;
                            try
                            {
                                o.Admin_Phone = Convert.ToInt32(AdminPhoneNoTextBox.Text);
                                o.Admin_Address = AdminAddressTextBox.Text;
                                o.Admin_Age = Convert.ToInt32(AdminAgeTextBox.Text);
                                if (AdminGenderMaleRadioButton.Checked)
                                {
                                    o.Admin_Gender = "male";
                                }
                                else if (AdminGenderFemaleRadioButton.Checked)
                                {
                                    o.Admin_Gender = "female";
                                }
                                o.Admin_Security = SecurityAnswerTextBox.Text;
                                o.Admin_ActiveStatus = "active";

                                User u = new User();
                                u.UserId = o.Admin_Id;
                                u.Password = PasswordTextBox.Text;
                                u.Active_status = "active";
                                u.Status = 0;
                                u.Security = SecurityAnswerTextBox.Text;

                                Admin_Data a = new Admin_Data();
                                a.InserAdmin(o);

                                LoginData x = new LoginData();
                                x.InsertUser(u);
                                MessageBox.Show("admin inserted.admin id" + o.Admin_Id, "add admin", MessageBoxButtons.OK);
                                AdminNameTextBox.Clear();
                                AdminPhoneNoTextBox.Clear();
                                AdminAddressTextBox.Clear();
                                AdminAgeTextBox.Clear();
                                SecurityAnswerTextBox.Clear();
                                PasswordTextBox.Clear();


                                AdminDataGridView.DataSource = a.GetAdminList();
                               
                            }
                            catch(Exception l)
                            {
                                MessageBox.Show("failed.invalid phone number", "add admin", MessageBoxButtons.OK);
                                AdminNameTextBox.Clear();
                                AdminPhoneNoTextBox.Clear();
                                AdminAddressTextBox.Clear();
                                AdminAgeTextBox.Clear();
                                SecurityAnswerTextBox.Clear();
                                PasswordTextBox.Clear();
                               

                            }
                            
                            
                        }
                        else
                        {
                            MessageBox.Show("failed.please answer the security question or provide password", "add admin", MessageBoxButtons.OK);
                            SecurityAnswerTextBox.Clear();
                            PasswordTextBox.Clear();


                        }
                    }

                    else
                    {
                        MessageBox.Show("failed.please proide gender", "add admin", MessageBoxButtons.OK);
                        SecurityAnswerTextBox.Clear();
                        PasswordTextBox.Clear();


                    }

                }

                else
                {
                    MessageBox.Show("failed.please proide Address or age", "add admin", MessageBoxButtons.OK);
                    AdminAddressTextBox.Clear();
                    AdminAgeTextBox.Clear();


                }
            }
            else
            {
                MessageBox.Show("failed.please proide name or phone number", "add admin", MessageBoxButtons.OK);
                AdminNameTextBox.Clear();
                AdminPhoneNoTextBox.Clear();


            }
       

        }

        public string createId()
        {
            Random xx = new Random();
            int y = xx.Next(0, 100000);
            string a = "A-" + y;
            return a;

        }

        private void AddAdmin_Load(object sender, EventArgs e)
        {
            Admin_Data a = new Admin_Data();
            AdminDataGridView.DataSource = a.GetAdminList();
        }

        private void AdminDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Id = AdminDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            AdminNameTextBox.Text = AdminDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            AdminPhoneNoTextBox.Text = AdminDataGridView.SelectedRows[0].Cells[2].Value.ToString();
            AdminAgeTextBox.Text = AdminDataGridView.SelectedRows[0].Cells[3].Value.ToString();
            AdminAddressTextBox.Text = AdminDataGridView.SelectedRows[0].Cells[4].Value.ToString();

            SecurityAnswerTextBox.Text = AdminDataGridView.SelectedRows[0].Cells[7].Value.ToString(); 
            PasswordTextBox.Clear();

        }

        private void DeleteAdminButton_Click(object sender, EventArgs e)
        {
            if (Id != null)
            {
                Admin_Data a = new Admin_Data();
                a.DeleteAdmin(Id);

                LoginData x = new LoginData();
                x.UpdateUser(Id, "inactive");

                AdminNameTextBox.Clear();
                AdminPhoneNoTextBox.Clear();
                AdminAddressTextBox.Clear();
                AdminAgeTextBox.Clear();
                SecurityAnswerTextBox.Clear();
                PasswordTextBox.Clear();


                AdminDataGridView.DataSource = a.GetAdminList();
                MessageBox.Show("admin DELETED.admin id" + Id, "add admin", MessageBoxButtons.OK);
                Id = null;

            }

            else
            {
                MessageBox.Show("please select an admin" , "add admin", MessageBoxButtons.OK);
            }
        }

        private void AddAdminGroupBox_Enter(object sender, EventArgs e)
        {

        }
    }
}
