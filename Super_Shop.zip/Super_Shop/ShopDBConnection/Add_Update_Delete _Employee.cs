﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Add_Update_Delete__Employee : Form
    {
        
        private string Id; 
        public Add_Update_Delete__Employee()
        {
            InitializeComponent();
            PhoneNoTextBox.MaxLength = 11;
            NameTextBox.MaxLength = 50;
            AgeTextBox.MaxLength = 3;
            AddressTextBox.MaxLength = 50;
            DesignationTextBox.MaxLength = 50;
            SecurityAnswerTextBox.MaxLength = 50;
            PasswordTextBox.MaxLength = 50;
            SalaryTextBox.MaxLength = 8;
        }

        private void NameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void AddressTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void PhoneNoTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void DesignationTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void AgeTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void SalaryTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin a = new Admin();
            a.Show();
        }

        private void Add_Update_Delete__Employee_Load(object sender, EventArgs e)
        {
            Employee_Data a = new Employee_Data();
            InsertEmployeeDataGridView.DataSource = a.GetEmployeeList();
        }

        private void InsertEmployeeButton_Click(object sender, EventArgs e)
        {
            if ((NameTextBox.Text != "") && (PhoneNoTextBox.Text != ""))
            {
                if ((AddressTextBox.Text) != "" && (AgeTextBox.Text != ""))
                {
                    if ((MaleRadioButton.Checked) || (FemaleRadioButton.Checked))
                    {
                        if ((SecurityAnswerTextBox.Text) != "" && (PasswordTextBox.Text != ""))
                        {
                            if ((DesignationTextBox.Text) != "" && (SalaryTextBox.Text != ""))
                            {
                                try
                                {
                                    EmployeeD o = new EmployeeD();
                                    o.Employee_Id = createId();
                                    o.Employee_Name = NameTextBox.Text;
                                    o.Employee_Phone = Convert.ToInt32(PhoneNoTextBox.Text);
                                    o.Employee_Addresss = AddressTextBox.Text;
                                    o.Employee_Age = Convert.ToInt32(AgeTextBox.Text);
                                    if (MaleRadioButton.Checked)
                                    {
                                        o.Employee_Gender = "male";
                                    }
                                    else if (FemaleRadioButton.Checked)
                                    {
                                        o.Employee_Gender = "female";
                                    }
                                    o.Employee_Security = SecurityAnswerTextBox.Text;
                                    o.Employee_Status = "active";
                                    o.Employee_Designation = DesignationTextBox.Text;
                                    o.Employee_Salary = Convert.ToInt32(SalaryTextBox.Text);

                                    User u = new User();
                                    u.UserId = o.Employee_Id;
                                    u.Password = PasswordTextBox.Text;
                                    u.Active_status = "active";
                                    u.Status = 1;
                                    u.Security = SecurityAnswerTextBox.Text;

                                    Employee_Data a = new Employee_Data();
                                    a.InserEmployee(o);

                                    LoginData x = new LoginData();
                                    x.InsertUser(u);
                                    MessageBox.Show("employee inserted.employee id" + o.Employee_Id, "add employee", MessageBoxButtons.OK);
                                    NameTextBox.Clear();
                                    PhoneNoTextBox.Clear();
                                    AddressTextBox.Clear();
                                    AgeTextBox.Clear();
                                    SecurityAnswerTextBox.Clear();
                                    PasswordTextBox.Clear();
                                    DesignationTextBox.Clear();
                                    SalaryTextBox.Clear();



                                    InsertEmployeeDataGridView.DataSource = a.GetEmployeeList();

                                }
                                catch (Exception x)
                                {
                                    MessageBox.Show("failed.Exception", "add employee", MessageBoxButtons.OK);
                                    NameTextBox.Clear();
                                    PhoneNoTextBox.Clear();
                                    AddressTextBox.Clear();
                                    AgeTextBox.Clear();
                                    SecurityAnswerTextBox.Clear();
                                    PasswordTextBox.Clear();
                                    DesignationTextBox.Clear();
                                    SalaryTextBox.Clear();
                                }
                            }
                            else
                            {
                                MessageBox.Show("failed.please provide Designation or Salary", "add employee", MessageBoxButtons.OK);
                                SecurityAnswerTextBox.Clear();
                                PasswordTextBox.Clear();


                            }

                        }
                        else
                        {
                            MessageBox.Show("failed.please answer the security question or provide password", "add employee", MessageBoxButtons.OK);
                            SecurityAnswerTextBox.Clear();
                            PasswordTextBox.Clear();


                        }
                    }

                    else
                    {
                        MessageBox.Show("failed.please proide gender", "add employee", MessageBoxButtons.OK);
                        SecurityAnswerTextBox.Clear();
                        PasswordTextBox.Clear();


                    }

                }

                else
                {
                    MessageBox.Show("failed.please proide Address or age", "add employee", MessageBoxButtons.OK);
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();


                }
            }
            else
            {
                MessageBox.Show("failed.please proide name or phone number", "add employee", MessageBoxButtons.OK);
                NameTextBox.Clear();
                PhoneNoTextBox.Clear();


            }
        }
        public string createId()
        {
            Random xx = new Random();
            int y = xx.Next(0, 100000);
            string a = "E-" + y;
            return a;

        }

        private void InsertEmployeeDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Id = InsertEmployeeDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            NameTextBox.Text = InsertEmployeeDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            PhoneNoTextBox.Text = InsertEmployeeDataGridView.SelectedRows[0].Cells[2].Value.ToString();
            AgeTextBox.Text = InsertEmployeeDataGridView.SelectedRows[0].Cells[3].Value.ToString();
            AddressTextBox.Text = InsertEmployeeDataGridView.SelectedRows[0].Cells[4].Value.ToString();
            DesignationTextBox.Text = InsertEmployeeDataGridView.SelectedRows[0].Cells[6].Value.ToString();
            SalaryTextBox.Text = InsertEmployeeDataGridView.SelectedRows[0].Cells[7].Value.ToString();

            SecurityAnswerTextBox.Text = InsertEmployeeDataGridView.SelectedRows[0].Cells[8].Value.ToString();
            PasswordTextBox.Clear();
        }

        private void DeleteEmployeeButton_Click(object sender, EventArgs e)
        {
            if (Id != null)
            {
                try
                {
                    Employee_Data a = new Employee_Data();
                    a.DeleteEmployee(Id);

                    LoginData x = new LoginData();
                    x.UpdateUser(Id, "inactive");

                    NameTextBox.Clear();
                    PhoneNoTextBox.Clear();
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();
                    SecurityAnswerTextBox.Clear();
                    PasswordTextBox.Clear();
                    DesignationTextBox.Clear();
                    SalaryTextBox.Clear();


                    InsertEmployeeDataGridView.DataSource = a.GetEmployeeList();
                    MessageBox.Show("Employee DELETED.employee id" + Id, "add Employee", MessageBoxButtons.OK);
                    Id = null;

                }
                catch (Exception x)
                {
                    MessageBox.Show("failed.Exception", "add employee", MessageBoxButtons.OK);
                    NameTextBox.Clear();
                    PhoneNoTextBox.Clear();
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();
                    SecurityAnswerTextBox.Clear();
                    PasswordTextBox.Clear();
                    DesignationTextBox.Clear();
                    SalaryTextBox.Clear();
                    Id = null;
                }
            }

            else
            {
                MessageBox.Show("please select an empolyee", "add empolyee", MessageBoxButtons.OK);
            }
        }

        private void UpdateEmployeeButton_Click(object sender, EventArgs e)
        {
            if (Id != null)
            {
                try
                {
                    Employee_Data a = new Employee_Data();
                    a.UpdateEmployee(Id, DesignationTextBox.Text, SalaryTextBox.Text.ToString());



                    NameTextBox.Clear();
                    PhoneNoTextBox.Clear();
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();
                    SecurityAnswerTextBox.Clear();
                    PasswordTextBox.Clear();
                    DesignationTextBox.Clear();
                    SalaryTextBox.Clear();


                    InsertEmployeeDataGridView.DataSource = a.GetEmployeeList();
                    MessageBox.Show("Employee updated.empolyee id" + Id, "add Employee", MessageBoxButtons.OK);
                    Id = null;
                }
                catch (Exception x)
                {
                    MessageBox.Show("failed.Exception", "add employee", MessageBoxButtons.OK);
                    NameTextBox.Clear();
                    PhoneNoTextBox.Clear();
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();
                    SecurityAnswerTextBox.Clear();
                    PasswordTextBox.Clear();
                    DesignationTextBox.Clear();
                    SalaryTextBox.Clear();
                    Id = null;
                }

            }

            else
            {
                MessageBox.Show("please select an empolyee", "add empolyee", MessageBoxButtons.OK);
            }
        }

        private void AgeTextBox_TextChanged(object sender, EventArgs e)
        {

        }

        private void SecurityAnswerLabel_Click(object sender, EventArgs e)
        {

        }

        private void SecurityQuestionLevel_Click(object sender, EventArgs e)
        {

        }
    }
}
