﻿namespace ShopDBConnection
{
    partial class Employee_UpdateInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.EmployeeUpdateInfoGroupbox = new System.Windows.Forms.GroupBox();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.IdTextBox = new System.Windows.Forms.TextBox();
            this.IdLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.USubmitButton = new System.Windows.Forms.Button();
            this.PhoneNotextBox1 = new System.Windows.Forms.TextBox();
            this.phoneNoLabel = new System.Windows.Forms.Label();
            this.EmployeeUpdateInfoGroupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // EmployeeUpdateInfoGroupbox
            // 
            this.EmployeeUpdateInfoGroupbox.Controls.Add(this.PasswordTextBox);
            this.EmployeeUpdateInfoGroupbox.Controls.Add(this.PasswordLabel);
            this.EmployeeUpdateInfoGroupbox.Controls.Add(this.IdTextBox);
            this.EmployeeUpdateInfoGroupbox.Controls.Add(this.IdLabel);
            this.EmployeeUpdateInfoGroupbox.Controls.Add(this.BackButton);
            this.EmployeeUpdateInfoGroupbox.Controls.Add(this.USubmitButton);
            this.EmployeeUpdateInfoGroupbox.Controls.Add(this.PhoneNotextBox1);
            this.EmployeeUpdateInfoGroupbox.Controls.Add(this.phoneNoLabel);
            this.EmployeeUpdateInfoGroupbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.EmployeeUpdateInfoGroupbox.Location = new System.Drawing.Point(121, 28);
            this.EmployeeUpdateInfoGroupbox.Name = "EmployeeUpdateInfoGroupbox";
            this.EmployeeUpdateInfoGroupbox.Size = new System.Drawing.Size(722, 642);
            this.EmployeeUpdateInfoGroupbox.TabIndex = 45;
            this.EmployeeUpdateInfoGroupbox.TabStop = false;
            this.EmployeeUpdateInfoGroupbox.Text = "Employee_Update Info";
            this.EmployeeUpdateInfoGroupbox.Enter += new System.EventHandler(this.EmployeeUpdateInfoGroupbox_Enter);
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(303, 260);
            this.PasswordTextBox.Multiline = true;
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(200, 33);
            this.PasswordTextBox.TabIndex = 49;
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordLabel.Location = new System.Drawing.Point(181, 260);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(98, 25);
            this.PasswordLabel.TabIndex = 48;
            this.PasswordLabel.Text = "Password";
            // 
            // IdTextBox
            // 
            this.IdTextBox.Location = new System.Drawing.Point(303, 141);
            this.IdTextBox.Multiline = true;
            this.IdTextBox.Name = "IdTextBox";
            this.IdTextBox.Size = new System.Drawing.Size(200, 33);
            this.IdTextBox.TabIndex = 47;
            // 
            // IdLabel
            // 
            this.IdLabel.AutoSize = true;
            this.IdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdLabel.Location = new System.Drawing.Point(236, 149);
            this.IdLabel.Name = "IdLabel";
            this.IdLabel.Size = new System.Drawing.Size(28, 25);
            this.IdLabel.TabIndex = 46;
            this.IdLabel.Text = "Id";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(416, 353);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 39;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // USubmitButton
            // 
            this.USubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.USubmitButton.Location = new System.Drawing.Point(303, 353);
            this.USubmitButton.Name = "USubmitButton";
            this.USubmitButton.Size = new System.Drawing.Size(87, 41);
            this.USubmitButton.TabIndex = 38;
            this.USubmitButton.Text = "Submit";
            this.USubmitButton.UseVisualStyleBackColor = true;
            this.USubmitButton.Click += new System.EventHandler(this.USubmitButton_Click);
            // 
            // PhoneNotextBox1
            // 
            this.PhoneNotextBox1.Location = new System.Drawing.Point(303, 192);
            this.PhoneNotextBox1.Multiline = true;
            this.PhoneNotextBox1.Name = "PhoneNotextBox1";
            this.PhoneNotextBox1.Size = new System.Drawing.Size(200, 33);
            this.PhoneNotextBox1.TabIndex = 2;
            this.PhoneNotextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PhoneNotextBox1_KeyPress);
            // 
            // phoneNoLabel
            // 
            this.phoneNoLabel.AutoSize = true;
            this.phoneNoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNoLabel.Location = new System.Drawing.Point(179, 196);
            this.phoneNoLabel.Name = "phoneNoLabel";
            this.phoneNoLabel.Size = new System.Drawing.Size(99, 25);
            this.phoneNoLabel.TabIndex = 0;
            this.phoneNoLabel.Text = "Phone No";
            // 
            // Employee_UpdateInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.EmployeeUpdateInfoGroupbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Employee_UpdateInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Employee_UpdateInfo";
            this.Load += new System.EventHandler(this.Employee_UpdateInfo_Load);
            this.EmployeeUpdateInfoGroupbox.ResumeLayout(false);
            this.EmployeeUpdateInfoGroupbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox EmployeeUpdateInfoGroupbox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button USubmitButton;
        private System.Windows.Forms.TextBox PhoneNotextBox1;
        private System.Windows.Forms.Label phoneNoLabel;
        private System.Windows.Forms.TextBox IdTextBox;
        private System.Windows.Forms.Label IdLabel;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label PasswordLabel;
    }
}