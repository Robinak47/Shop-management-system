﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Customer_Home : Form
    {
        User u;
        public Customer_Home(User user)
        {
            u = user;
            InitializeComponent();
        }

        private void UpdateSelfInfoButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_UpdateInfo a = new Customer_UpdateInfo(u);
            a.Show();
        }

        private void ChangePasswordButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Change_Password a = new Customer_Change_Password(u);
            a.Show();
        }

        private void ProductButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Product a = new Customer_Product(u);
            a.Show();
        }

        private void ShowOrderButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Order a = new Customer_Order(u);
            a.Show();
        }

        private void Customer_Home_Load(object sender, EventArgs e)
        {

        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login_Form a = new Login_Form();
            a.Show();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }
    }
}
