﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;
namespace ShopDBConnection
{
    public partial class Customer : Form
    {
        public Customer()
        {
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Admin a = new Admin();
            a.Show();
        }

        private void Customer_Load(object sender, EventArgs e)
        {
             Customer_Data a = new Customer_Data();
             CustomerDataGridView.DataSource = a.GetCustomerList();
            
        }
    }
}
