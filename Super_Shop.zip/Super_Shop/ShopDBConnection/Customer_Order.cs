﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Customer_Order : Form
    {
        User u;
        public Customer_Order(User user)
        {
            u = user;
            InitializeComponent();
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Home a = new Customer_Home(u);
            a.Show();
        }

        private void Customer_Order_Load(object sender, EventArgs e)
        {
            Order_Data a = new Order_Data();
            CustomerOrderDataGridView.DataSource = a.GetOrderList1(u.UserId);
        }

        private void getbtn_Click(object sender, EventArgs e)
        {
            
        }
    }
}
