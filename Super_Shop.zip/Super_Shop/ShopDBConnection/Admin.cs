﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ShopDBConnection
{
    public partial class Admin : Form
    {
        public Admin()
        {
            InitializeComponent();
        }

       
        private void Admin_Load(object sender, EventArgs e)
        {
            
        }

        private void AddAdminButton_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            AddAdmin a = new AddAdmin();
            a.Show();
        }

        private void AddEmployeeButton_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Add_Update_Delete__Employee a = new Add_Update_Delete__Employee();
            a.Show();
        }

        private void ProductButton_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Product a = new Product();
            a.Show();
        }

        private void BillButton_Click_1(object sender, EventArgs e)
        {

            this.Hide();
            Bill a = new Bill();
            a.Show();
        }

        private void CustomerButton_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            Customer a = new Customer();
            a.Show();
        }

        private void ChangePasswordButton_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            ChangePassword a = new ChangePassword();
            a.Show();   
        }

        private void UpdateSelfInfoButton_Click_1(object sender, EventArgs e)
        {
            this.Hide();
            UpdateInfo a = new UpdateInfo();
            a.Show();
        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void LogOutButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login_Form a = new Login_Form();
            a.Show();
        }

       
    }
}
