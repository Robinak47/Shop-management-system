﻿namespace ShopDBConnection
{
    partial class AddAdmin
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.AddAdminGroupBox = new System.Windows.Forms.GroupBox();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.SecurityAnswerTextBox = new System.Windows.Forms.TextBox();
            this.SecurityAnswerLabel = new System.Windows.Forms.Label();
            this.SecurityQuestionTextBox = new System.Windows.Forms.TextBox();
            this.SecurityQuestionLevel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.DeleteAdminButton = new System.Windows.Forms.Button();
            this.AdminGenderFemaleRadioButton = new System.Windows.Forms.RadioButton();
            this.AdminGenderMaleRadioButton = new System.Windows.Forms.RadioButton();
            this.AdminGenderLabel = new System.Windows.Forms.Label();
            this.AdminAgeTextBox = new System.Windows.Forms.TextBox();
            this.AdminNameTextBox = new System.Windows.Forms.TextBox();
            this.AdminNameLabel = new System.Windows.Forms.Label();
            this.AdminAgeLabel = new System.Windows.Forms.Label();
            this.InsertAdminButton = new System.Windows.Forms.Button();
            this.AdminAddressTextBox = new System.Windows.Forms.TextBox();
            this.AdminPhoneNoTextBox = new System.Windows.Forms.TextBox();
            this.AdminAddresslabel = new System.Windows.Forms.Label();
            this.AdminPhoneNoLabel = new System.Windows.Forms.Label();
            this.AdminDataGridView = new System.Windows.Forms.DataGridView();
            this.AddAdminGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AdminDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // AddAdminGroupBox
            // 
            this.AddAdminGroupBox.Controls.Add(this.PasswordTextBox);
            this.AddAdminGroupBox.Controls.Add(this.PasswordLabel);
            this.AddAdminGroupBox.Controls.Add(this.SecurityAnswerTextBox);
            this.AddAdminGroupBox.Controls.Add(this.SecurityAnswerLabel);
            this.AddAdminGroupBox.Controls.Add(this.SecurityQuestionTextBox);
            this.AddAdminGroupBox.Controls.Add(this.SecurityQuestionLevel);
            this.AddAdminGroupBox.Controls.Add(this.BackButton);
            this.AddAdminGroupBox.Controls.Add(this.AdminDataGridView);
            this.AddAdminGroupBox.Controls.Add(this.DeleteAdminButton);
            this.AddAdminGroupBox.Controls.Add(this.AdminGenderFemaleRadioButton);
            this.AddAdminGroupBox.Controls.Add(this.AdminGenderMaleRadioButton);
            this.AddAdminGroupBox.Controls.Add(this.AdminGenderLabel);
            this.AddAdminGroupBox.Controls.Add(this.AdminAgeTextBox);
            this.AddAdminGroupBox.Controls.Add(this.AdminNameTextBox);
            this.AddAdminGroupBox.Controls.Add(this.AdminNameLabel);
            this.AddAdminGroupBox.Controls.Add(this.AdminAgeLabel);
            this.AddAdminGroupBox.Controls.Add(this.InsertAdminButton);
            this.AddAdminGroupBox.Controls.Add(this.AdminAddressTextBox);
            this.AddAdminGroupBox.Controls.Add(this.AdminPhoneNoTextBox);
            this.AddAdminGroupBox.Controls.Add(this.AdminAddresslabel);
            this.AddAdminGroupBox.Controls.Add(this.AdminPhoneNoLabel);
            this.AddAdminGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddAdminGroupBox.Location = new System.Drawing.Point(90, 12);
            this.AddAdminGroupBox.Name = "AddAdminGroupBox";
            this.AddAdminGroupBox.Size = new System.Drawing.Size(805, 628);
            this.AddAdminGroupBox.TabIndex = 45;
            this.AddAdminGroupBox.TabStop = false;
            this.AddAdminGroupBox.Text = "Add Admin";
            this.AddAdminGroupBox.Enter += new System.EventHandler(this.AddAdminGroupBox_Enter);
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(541, 33);
            this.PasswordTextBox.Multiline = true;
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(200, 33);
            this.PasswordTextBox.TabIndex = 7;
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordLabel.Location = new System.Drawing.Point(420, 35);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(98, 25);
            this.PasswordLabel.TabIndex = 52;
            this.PasswordLabel.Text = "Password";
            // 
            // SecurityAnswerTextBox
            // 
            this.SecurityAnswerTextBox.Location = new System.Drawing.Point(541, 160);
            this.SecurityAnswerTextBox.Multiline = true;
            this.SecurityAnswerTextBox.Name = "SecurityAnswerTextBox";
            this.SecurityAnswerTextBox.Size = new System.Drawing.Size(200, 33);
            this.SecurityAnswerTextBox.TabIndex = 6;
            this.SecurityAnswerTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.SecurityAnswerTextBox_KeyPress);
            // 
            // SecurityAnswerLabel
            // 
            this.SecurityAnswerLabel.AutoSize = true;
            this.SecurityAnswerLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecurityAnswerLabel.Location = new System.Drawing.Point(381, 159);
            this.SecurityAnswerLabel.Name = "SecurityAnswerLabel";
            this.SecurityAnswerLabel.Size = new System.Drawing.Size(154, 25);
            this.SecurityAnswerLabel.TabIndex = 50;
            this.SecurityAnswerLabel.Text = "Security Answer";
            // 
            // SecurityQuestionTextBox
            // 
            this.SecurityQuestionTextBox.Location = new System.Drawing.Point(541, 91);
            this.SecurityQuestionTextBox.Multiline = true;
            this.SecurityQuestionTextBox.Name = "SecurityQuestionTextBox";
            this.SecurityQuestionTextBox.ReadOnly = true;
            this.SecurityQuestionTextBox.Size = new System.Drawing.Size(221, 33);
            this.SecurityQuestionTextBox.TabIndex = 49;
            this.SecurityQuestionTextBox.Text = "what\'s your 1st pet name? ";
            // 
            // SecurityQuestionLevel
            // 
            this.SecurityQuestionLevel.AutoSize = true;
            this.SecurityQuestionLevel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.SecurityQuestionLevel.Location = new System.Drawing.Point(373, 91);
            this.SecurityQuestionLevel.Name = "SecurityQuestionLevel";
            this.SecurityQuestionLevel.Size = new System.Drawing.Size(162, 25);
            this.SecurityQuestionLevel.TabIndex = 48;
            this.SecurityQuestionLevel.Text = "Security question";
            // 
            // BackButton
            // 
            this.BackButton.BackColor = System.Drawing.Color.White;
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(654, 326);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 46;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = false;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // DeleteAdminButton
            // 
            this.DeleteAdminButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteAdminButton.Location = new System.Drawing.Point(355, 326);
            this.DeleteAdminButton.Name = "DeleteAdminButton";
            this.DeleteAdminButton.Size = new System.Drawing.Size(163, 42);
            this.DeleteAdminButton.TabIndex = 46;
            this.DeleteAdminButton.Text = "Delete Admin";
            this.DeleteAdminButton.UseVisualStyleBackColor = true;
            this.DeleteAdminButton.Click += new System.EventHandler(this.DeleteAdminButton_Click);
            // 
            // AdminGenderFemaleRadioButton
            // 
            this.AdminGenderFemaleRadioButton.AutoSize = true;
            this.AdminGenderFemaleRadioButton.Location = new System.Drawing.Point(224, 249);
            this.AdminGenderFemaleRadioButton.Name = "AdminGenderFemaleRadioButton";
            this.AdminGenderFemaleRadioButton.Size = new System.Drawing.Size(85, 24);
            this.AdminGenderFemaleRadioButton.TabIndex = 5;
            this.AdminGenderFemaleRadioButton.TabStop = true;
            this.AdminGenderFemaleRadioButton.Text = "Female";
            this.AdminGenderFemaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // AdminGenderMaleRadioButton
            // 
            this.AdminGenderMaleRadioButton.AutoSize = true;
            this.AdminGenderMaleRadioButton.Location = new System.Drawing.Point(137, 249);
            this.AdminGenderMaleRadioButton.Name = "AdminGenderMaleRadioButton";
            this.AdminGenderMaleRadioButton.Size = new System.Drawing.Size(66, 24);
            this.AdminGenderMaleRadioButton.TabIndex = 4;
            this.AdminGenderMaleRadioButton.TabStop = true;
            this.AdminGenderMaleRadioButton.Text = "Male";
            this.AdminGenderMaleRadioButton.UseVisualStyleBackColor = true;
            // 
            // AdminGenderLabel
            // 
            this.AdminGenderLabel.AutoSize = true;
            this.AdminGenderLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminGenderLabel.Location = new System.Drawing.Point(43, 249);
            this.AdminGenderLabel.Name = "AdminGenderLabel";
            this.AdminGenderLabel.Size = new System.Drawing.Size(77, 25);
            this.AdminGenderLabel.TabIndex = 43;
            this.AdminGenderLabel.Text = "Gender";
            // 
            // AdminAgeTextBox
            // 
            this.AdminAgeTextBox.Location = new System.Drawing.Point(134, 187);
            this.AdminAgeTextBox.Multiline = true;
            this.AdminAgeTextBox.Name = "AdminAgeTextBox";
            this.AdminAgeTextBox.Size = new System.Drawing.Size(200, 33);
            this.AdminAgeTextBox.TabIndex = 3;
            this.AdminAgeTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AdminAgeTextBox_KeyPress);
            // 
            // AdminNameTextBox
            // 
            this.AdminNameTextBox.Location = new System.Drawing.Point(134, 33);
            this.AdminNameTextBox.Multiline = true;
            this.AdminNameTextBox.Name = "AdminNameTextBox";
            this.AdminNameTextBox.Size = new System.Drawing.Size(200, 33);
            this.AdminNameTextBox.TabIndex = 0;
            this.AdminNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AdminNameTextBox_KeyPress);
            // 
            // AdminNameLabel
            // 
            this.AdminNameLabel.AutoSize = true;
            this.AdminNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminNameLabel.Location = new System.Drawing.Point(56, 35);
            this.AdminNameLabel.Name = "AdminNameLabel";
            this.AdminNameLabel.Size = new System.Drawing.Size(64, 25);
            this.AdminNameLabel.TabIndex = 40;
            this.AdminNameLabel.Text = "Name";
            // 
            // AdminAgeLabel
            // 
            this.AdminAgeLabel.AutoSize = true;
            this.AdminAgeLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminAgeLabel.Location = new System.Drawing.Point(56, 195);
            this.AdminAgeLabel.Name = "AdminAgeLabel";
            this.AdminAgeLabel.Size = new System.Drawing.Size(48, 25);
            this.AdminAgeLabel.TabIndex = 39;
            this.AdminAgeLabel.Text = "Age";
            // 
            // InsertAdminButton
            // 
            this.InsertAdminButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.InsertAdminButton.Location = new System.Drawing.Point(48, 326);
            this.InsertAdminButton.Name = "InsertAdminButton";
            this.InsertAdminButton.Size = new System.Drawing.Size(163, 42);
            this.InsertAdminButton.TabIndex = 38;
            this.InsertAdminButton.Text = "Insert Admin";
            this.InsertAdminButton.UseVisualStyleBackColor = true;
            this.InsertAdminButton.Click += new System.EventHandler(this.InsertAdminButton_Click);
            // 
            // AdminAddressTextBox
            // 
            this.AdminAddressTextBox.Location = new System.Drawing.Point(134, 140);
            this.AdminAddressTextBox.Multiline = true;
            this.AdminAddressTextBox.Name = "AdminAddressTextBox";
            this.AdminAddressTextBox.Size = new System.Drawing.Size(200, 33);
            this.AdminAddressTextBox.TabIndex = 2;
            this.AdminAddressTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AdminAddressTextBox_KeyPress);
            // 
            // AdminPhoneNoTextBox
            // 
            this.AdminPhoneNoTextBox.Location = new System.Drawing.Point(134, 82);
            this.AdminPhoneNoTextBox.Multiline = true;
            this.AdminPhoneNoTextBox.Name = "AdminPhoneNoTextBox";
            this.AdminPhoneNoTextBox.Size = new System.Drawing.Size(200, 33);
            this.AdminPhoneNoTextBox.TabIndex = 1;
            this.AdminPhoneNoTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.AdminPhoneNoTextBox_KeyPress);
            // 
            // AdminAddresslabel
            // 
            this.AdminAddresslabel.AutoSize = true;
            this.AdminAddresslabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminAddresslabel.Location = new System.Drawing.Point(35, 148);
            this.AdminAddresslabel.Name = "AdminAddresslabel";
            this.AdminAddresslabel.Size = new System.Drawing.Size(85, 25);
            this.AdminAddresslabel.TabIndex = 1;
            this.AdminAddresslabel.Text = "Address";
            // 
            // AdminPhoneNoLabel
            // 
            this.AdminPhoneNoLabel.AutoSize = true;
            this.AdminPhoneNoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AdminPhoneNoLabel.Location = new System.Drawing.Point(21, 90);
            this.AdminPhoneNoLabel.Name = "AdminPhoneNoLabel";
            this.AdminPhoneNoLabel.Size = new System.Drawing.Size(99, 25);
            this.AdminPhoneNoLabel.TabIndex = 0;
            this.AdminPhoneNoLabel.Text = "Phone No";
            // 
            // AdminDataGridView
            // 
            this.AdminDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.AdminDataGridView.Location = new System.Drawing.Point(48, 391);
            this.AdminDataGridView.Name = "AdminDataGridView";
            this.AdminDataGridView.RowHeadersWidth = 51;
            this.AdminDataGridView.RowTemplate.Height = 24;
            this.AdminDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.AdminDataGridView.Size = new System.Drawing.Size(720, 214);
            this.AdminDataGridView.TabIndex = 47;
            this.AdminDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.AdminDataGridView_CellClick);
            // 
            // AddAdmin
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.AddAdminGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AddAdmin";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AddAdmin";
            this.Load += new System.EventHandler(this.AddAdmin_Load);
            this.AddAdminGroupBox.ResumeLayout(false);
            this.AddAdminGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.AdminDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox AddAdminGroupBox;
        private System.Windows.Forms.Button DeleteAdminButton;
        private System.Windows.Forms.RadioButton AdminGenderFemaleRadioButton;
        private System.Windows.Forms.RadioButton AdminGenderMaleRadioButton;
        private System.Windows.Forms.Label AdminGenderLabel;
        private System.Windows.Forms.TextBox AdminAgeTextBox;
        private System.Windows.Forms.TextBox AdminNameTextBox;
        private System.Windows.Forms.Label AdminNameLabel;
        private System.Windows.Forms.Label AdminAgeLabel;
        private System.Windows.Forms.Button InsertAdminButton;
        private System.Windows.Forms.TextBox AdminAddressTextBox;
        private System.Windows.Forms.TextBox AdminPhoneNoTextBox;
        private System.Windows.Forms.Label AdminAddresslabel;
        private System.Windows.Forms.Label AdminPhoneNoLabel;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.TextBox SecurityAnswerTextBox;
        private System.Windows.Forms.Label SecurityAnswerLabel;
        private System.Windows.Forms.TextBox SecurityQuestionTextBox;
        private System.Windows.Forms.Label SecurityQuestionLevel;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.DataGridView AdminDataGridView;
    }
}