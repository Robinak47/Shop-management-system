﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Customer_UpdateInfo : Form
    {
        User u;
        public Customer_UpdateInfo(User user)
        {
            u = user;
            InitializeComponent();
            PhoneNotextBox1.MaxLength = 11;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Customer_Home a = new Customer_Home(u);
            a.Show();
        }

        private void PhoneNotextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void AddressTextBox1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void USubmitButton_Click(object sender, EventArgs e)
        {
            if ((IdTextBox.Text != "") && PasswordTextBox.Text != "")
            {
                if (PhoneNotextBox1.Text != "")
                {
                    try
                    {
                        User user = new User();
                        LoginData a = new LoginData();
                        user = a.getuser(IdTextBox.Text, PasswordTextBox.Text);
                        if (user.UserId == IdTextBox.Text)
                        {
                            Customer_Data x = new Customer_Data();
                            x.UpdateSelfInfo(IdTextBox.Text, Convert.ToInt32(PhoneNotextBox1.Text));
                            MessageBox.Show("updated", "done", MessageBoxButtons.OK);
                            IdTextBox.Clear();
                            PasswordTextBox.Clear();
                            PhoneNotextBox1.Clear();

                        }
                        else
                        {
                            MessageBox.Show("wrong id or password", "failed", MessageBoxButtons.OK);
                            IdTextBox.Clear();
                            PasswordTextBox.Clear();
                            PhoneNotextBox1.Clear();
                        }

                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Exception", "failed", MessageBoxButtons.OK);
                        IdTextBox.Clear();
                        PasswordTextBox.Clear();
                        PhoneNotextBox1.Clear();
                    }
                }

                else
                {
                    MessageBox.Show("please fill all field", "failed", MessageBoxButtons.OK);
                    IdTextBox.Clear();
                    PasswordTextBox.Clear();
                    PhoneNotextBox1.Clear();
                }
            }
            else
            {
                MessageBox.Show("please fill all field", "failed", MessageBoxButtons.OK);
                IdTextBox.Clear();
                PasswordTextBox.Clear();
                PhoneNotextBox1.Clear();
            }
        }

        private void Customer_UpdateInfo_Load(object sender, EventArgs e)
        {

        }
    }
}
