﻿namespace ShopDBConnection
{
    partial class Update_Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.UpdateOrderGroupBox = new System.Windows.Forms.GroupBox();
            this.OrderIdTextBox = new System.Windows.Forms.TextBox();
            this.OrderIdLabel = new System.Windows.Forms.Label();
            this.UpdateOrderButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.UpdateOrderDataGridView = new System.Windows.Forms.DataGridView();
            this.ProductIdTextBox = new System.Windows.Forms.TextBox();
            this.productIdLabel = new System.Windows.Forms.Label();
            this.QuantityTextBox = new System.Windows.Forms.TextBox();
            this.QuantityLabel = new System.Windows.Forms.Label();
            this.UpdateOrderGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UpdateOrderDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // UpdateOrderGroupBox
            // 
            this.UpdateOrderGroupBox.Controls.Add(this.OrderIdTextBox);
            this.UpdateOrderGroupBox.Controls.Add(this.OrderIdLabel);
            this.UpdateOrderGroupBox.Controls.Add(this.UpdateOrderButton);
            this.UpdateOrderGroupBox.Controls.Add(this.BackButton);
            this.UpdateOrderGroupBox.Controls.Add(this.UpdateOrderDataGridView);
            this.UpdateOrderGroupBox.Controls.Add(this.ProductIdTextBox);
            this.UpdateOrderGroupBox.Controls.Add(this.productIdLabel);
            this.UpdateOrderGroupBox.Controls.Add(this.QuantityTextBox);
            this.UpdateOrderGroupBox.Controls.Add(this.QuantityLabel);
            this.UpdateOrderGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateOrderGroupBox.Location = new System.Drawing.Point(80, 35);
            this.UpdateOrderGroupBox.Name = "UpdateOrderGroupBox";
            this.UpdateOrderGroupBox.Size = new System.Drawing.Size(805, 628);
            this.UpdateOrderGroupBox.TabIndex = 47;
            this.UpdateOrderGroupBox.TabStop = false;
            this.UpdateOrderGroupBox.Text = "Update order";
            // 
            // OrderIdTextBox
            // 
            this.OrderIdTextBox.Location = new System.Drawing.Point(347, 125);
            this.OrderIdTextBox.Multiline = true;
            this.OrderIdTextBox.Name = "OrderIdTextBox";
            this.OrderIdTextBox.Size = new System.Drawing.Size(200, 33);
            this.OrderIdTextBox.TabIndex = 50;
            // 
            // OrderIdLabel
            // 
            this.OrderIdLabel.AutoSize = true;
            this.OrderIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.OrderIdLabel.Location = new System.Drawing.Point(236, 125);
            this.OrderIdLabel.Name = "OrderIdLabel";
            this.OrderIdLabel.Size = new System.Drawing.Size(83, 25);
            this.OrderIdLabel.TabIndex = 49;
            this.OrderIdLabel.Text = "Order Id";
            // 
            // UpdateOrderButton
            // 
            this.UpdateOrderButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateOrderButton.Location = new System.Drawing.Point(270, 343);
            this.UpdateOrderButton.Name = "UpdateOrderButton";
            this.UpdateOrderButton.Size = new System.Drawing.Size(163, 42);
            this.UpdateOrderButton.TabIndex = 48;
            this.UpdateOrderButton.Text = "Update Order";
            this.UpdateOrderButton.UseVisualStyleBackColor = true;
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(496, 342);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 46;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // UpdateOrderDataGridView
            // 
            this.UpdateOrderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.UpdateOrderDataGridView.Location = new System.Drawing.Point(48, 391);
            this.UpdateOrderDataGridView.Name = "UpdateOrderDataGridView";
            this.UpdateOrderDataGridView.RowHeadersWidth = 51;
            this.UpdateOrderDataGridView.RowTemplate.Height = 24;
            this.UpdateOrderDataGridView.Size = new System.Drawing.Size(720, 214);
            this.UpdateOrderDataGridView.TabIndex = 47;
            // 
            // ProductIdTextBox
            // 
            this.ProductIdTextBox.Location = new System.Drawing.Point(347, 184);
            this.ProductIdTextBox.Multiline = true;
            this.ProductIdTextBox.Name = "ProductIdTextBox";
            this.ProductIdTextBox.Size = new System.Drawing.Size(200, 33);
            this.ProductIdTextBox.TabIndex = 41;
            // 
            // productIdLabel
            // 
            this.productIdLabel.AutoSize = true;
            this.productIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productIdLabel.Location = new System.Drawing.Point(236, 184);
            this.productIdLabel.Name = "productIdLabel";
            this.productIdLabel.Size = new System.Drawing.Size(100, 25);
            this.productIdLabel.TabIndex = 40;
            this.productIdLabel.Text = "Product Id";
            // 
            // QuantityTextBox
            // 
            this.QuantityTextBox.Location = new System.Drawing.Point(347, 243);
            this.QuantityTextBox.Multiline = true;
            this.QuantityTextBox.Name = "QuantityTextBox";
            this.QuantityTextBox.Size = new System.Drawing.Size(200, 33);
            this.QuantityTextBox.TabIndex = 2;
            this.QuantityTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.QuantityTextBox_KeyPress);
            // 
            // QuantityLabel
            // 
            this.QuantityLabel.AutoSize = true;
            this.QuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityLabel.Location = new System.Drawing.Point(251, 243);
            this.QuantityLabel.Name = "QuantityLabel";
            this.QuantityLabel.Size = new System.Drawing.Size(85, 25);
            this.QuantityLabel.TabIndex = 0;
            this.QuantityLabel.Text = "Quantity";
            // 
            // Update_Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.UpdateOrderGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Update_Order";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Update_Order";
            this.UpdateOrderGroupBox.ResumeLayout(false);
            this.UpdateOrderGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.UpdateOrderDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox UpdateOrderGroupBox;
        private System.Windows.Forms.TextBox OrderIdTextBox;
        private System.Windows.Forms.Label OrderIdLabel;
        private System.Windows.Forms.Button UpdateOrderButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.DataGridView UpdateOrderDataGridView;
        private System.Windows.Forms.TextBox ProductIdTextBox;
        private System.Windows.Forms.Label productIdLabel;
        private System.Windows.Forms.TextBox QuantityTextBox;
        private System.Windows.Forms.Label QuantityLabel;
    }
}