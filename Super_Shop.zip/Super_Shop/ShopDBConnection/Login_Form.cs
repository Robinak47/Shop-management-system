﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Login_Form : Form
    {
        public Login_Form()
        {
            InitializeComponent();
            PasswordTextBox.PasswordChar = '*';
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void ExitButton_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void ShowCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            if (ShowCheckBox.Checked)
            {
                PasswordTextBox.UseSystemPasswordChar = true;
            }

            else
            {
                PasswordTextBox.UseSystemPasswordChar = false;

            }
        }

        private void LoginButton_Click(object sender, EventArgs e)
        {
            LoginData lg = new LoginData();
            User user = lg.getuser(UserIdTextBox.Text, PasswordTextBox.Text);
            if (user != null)
            {
                if (user.Active_status == "active" && user.Status == 0)
                {
                    this.Hide();
                    Admin admin = new Admin();
                    admin.Show();
                }

                else if (user.Active_status == "active" && user.Status == 1)
                {
                    this.Hide();
                    Employee_Home s = new Employee_Home();
                    s.Show();
                }

                else if (user.Active_status == "active" && user.Status == 2)
                {
                    this.Hide();
                     Customer_Home s = new Customer_Home(user);
                    s.Show();
                }

                else
                {
                    MessageBox.Show("wrong user Id or Password", "login failed", MessageBoxButtons.OK);
                    UserIdTextBox.Clear();
                    PasswordTextBox.Clear();
                    


                }
              
            }

            
        }

       

        private void ForgetPasswordButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Forget_Password f = new Forget_Password();
            f.Show();
        }

        private void Login_Form_Load(object sender, EventArgs e)
        {

        }

        
    }
}
