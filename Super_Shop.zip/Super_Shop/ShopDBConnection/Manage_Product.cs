﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;

namespace ShopDBConnection
{
    public partial class Manage_Product : Form
    {
        private string Id;
        public Manage_Product()
        {
           
            InitializeComponent();
            ProductNameTextBox.MaxLength = 50;
            QuantityTextbox.MaxLength = 9;
            PriceTextBox.MaxLength = 9;
        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Employee_Home a = new Employee_Home();
            a.Show();
        }

        private void ProductNameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void QuantityTextbox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void PriceTextBox_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void PriceTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void ManageProductGroupBox1_Enter(object sender, EventArgs e)
        {
            Product_Data a = new Product_Data();
            ManageProductGridView.DataSource = a.GetProductList();
        }

        private void AddProductButton_Click(object sender, EventArgs e)
        {

            if ((ProductNameTextBox.Text != "") && (QuantityTextbox.Text != ""))
            {
                if ((PriceTextBox.Text) != "")
                {
                    try
                    {
                        ProductD o = new ProductD();
                        o.Product_Id = createId();
                        o.Product_Name = ProductNameTextBox.Text;
                        o.Quantity = Convert.ToInt32(QuantityTextbox.Text);
                        o.Price = Convert.ToInt32(PriceTextBox.Text);
                        o.Product_Status = "active";






                        Product_Data a = new Product_Data();
                        a.InsertProduct(o);


                        MessageBox.Show("Product inserted.Product id" + o.Product_Id, "add Product", MessageBoxButtons.OK);
                        ProductNameTextBox.Clear();
                        QuantityTextbox.Clear();
                        PriceTextBox.Clear();





                        ManageProductGridView.DataSource = a.GetProductList();



                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Exception", "failed", MessageBoxButtons.OK);
                        ProductNameTextBox.Clear();
                        QuantityTextbox.Clear();
                        PriceTextBox.Clear();
                    }
                }
                else
                {
                    MessageBox.Show("failed.please provide price", "add product", MessageBoxButtons.OK);



                }
                    }

                    else
                    {
                        MessageBox.Show("failed.please proide name or quantity", "add product", MessageBoxButtons.OK);
                        ProductNameTextBox.Clear();
                        QuantityTextbox.Clear();


                    }

                }

                

        public string createId()
        {
            Random xx = new Random();
            int y = xx.Next(0, 100000);
            string a = "P-" + y;
            return a;

        }

        private void DeleteproductButton_Click(object sender, EventArgs e)
        {
            if (Id != null)
            {
                try
                {
                    Product_Data a = new Product_Data();
                    a.DeleteProduct(Id);



                    ProductNameTextBox.Clear();
                    QuantityTextbox.Clear();
                    PriceTextBox.Clear();


                    ManageProductGridView.DataSource = a.GetProductList();
                    MessageBox.Show("Product DELETED.Product id" + Id, "add Product", MessageBoxButtons.OK);
                    Id = null;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception", "failed", MessageBoxButtons.OK);
                    ProductNameTextBox.Clear();
                    QuantityTextbox.Clear();
                    PriceTextBox.Clear();
                    Id = null;

                }
            }
            else
            {
                MessageBox.Show("please select a product", "add Product", MessageBoxButtons.OK);
            }
        }

        private void ManageProductGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Id = ManageProductGridView.SelectedRows[0].Cells[0].Value.ToString();
            ProductNameTextBox.Text = ManageProductGridView.SelectedRows[0].Cells[1].Value.ToString();
            QuantityTextbox.Text = ManageProductGridView.SelectedRows[0].Cells[2].Value.ToString();
            PriceTextBox.Text = ManageProductGridView.SelectedRows[0].Cells[3].Value.ToString();
            
        }

        private void UpdateProductButton_Click(object sender, EventArgs e)
        {
            if (Id != null)
            {
                try
                {
                    Product_Data a = new Product_Data();
                    a.UpdateProduct(Id, Convert.ToInt32(QuantityTextbox.Text), Convert.ToInt32(PriceTextBox.Text));



                    ProductNameTextBox.Clear();
                    QuantityTextbox.Clear();
                    PriceTextBox.Clear();


                    ManageProductGridView.DataSource = a.GetProductList();
                    MessageBox.Show("Product Updated.Product id" + Id, "add Product", MessageBoxButtons.OK);
                    Id = null;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception", "failed", MessageBoxButtons.OK);
                    ProductNameTextBox.Clear();
                    QuantityTextbox.Clear();
                    PriceTextBox.Clear();
                    Id = null;
                }

            }

            else
            {
                MessageBox.Show("please select a Product", "add Product", MessageBoxButtons.OK);
            }
        }

        private void Manage_Product_Load(object sender, EventArgs e)
        {

        }
    }
}
