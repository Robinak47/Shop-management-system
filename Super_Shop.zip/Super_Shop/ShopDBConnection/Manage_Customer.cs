﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Shop.Entities;
using Shop.DataAccess;
namespace ShopDBConnection
{
    public partial class Manage_Customer : Form
    {
        private string Id;
        public Manage_Customer()
        {
            InitializeComponent();
            NameTextBox.MaxLength = 50;
            PhoneNoTextBox.MaxLength = 11;
            AddressTextBox.MaxLength = 50;
            AgeTextBox.MaxLength = 3;
            SecurityAnswerTextBox.MaxLength = 50;
            PasswordTextBox.MaxLength = 50;

        }

        private void BackButton_Click(object sender, EventArgs e)
        {
            this.Hide();
            Employee_Home a = new Employee_Home();

            a.Show();
        }

        private void NameTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)) && (!char.IsWhiteSpace(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void PhoneNoTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void AddressTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsLetter(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void AgeTextBox_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsNumber(e.KeyChar) && (!char.IsControl(e.KeyChar)))
            {
                e.Handled = true;
            }
        }

        private void Manage_Customer_Load(object sender, EventArgs e)
        {
            Customer_Data a = new Customer_Data();
            ManageCustomerDataGridView.DataSource = a.GetCustomerList();
        }

        private void InsertCustomerButton_Click(object sender, EventArgs e)
        {
            if ((NameTextBox.Text != "") && (PhoneNoTextBox.Text != ""))
            {
                if ((AddressTextBox.Text) != "" && (AgeTextBox.Text != ""))
                {
                    if ((GenderMaleRadioButton.Checked) || (GenderFemaleRadioButton.Checked))
                    {
                        if ((SecurityAnswerTextBox.Text) != "" && (PasswordTextBox.Text != ""))
                        {
                            try
                            {
                                CustomerD o = new CustomerD();
                                o.Customer_Id = createId();
                                o.Customer_Name = NameTextBox.Text;
                                o.Customer_Phone = Convert.ToInt32(PhoneNoTextBox.Text);
                                o.Customer_Address = AddressTextBox.Text;
                                o.Customer_Age = Convert.ToInt32(AgeTextBox.Text);
                                if (GenderMaleRadioButton.Checked)
                                {
                                    o.Customer_Gender = "male";
                                }
                                else if (GenderFemaleRadioButton.Checked)
                                {
                                    o.Customer_Gender = "female";
                                }
                                o.Customer_Security = SecurityAnswerTextBox.Text;
                                o.Customer_Status = "active";


                                User u = new User();
                                u.UserId = o.Customer_Id;
                                u.Password = PasswordTextBox.Text;
                                u.Active_status = "active";
                                u.Status = 2;
                                u.Security = SecurityAnswerTextBox.Text;

                                Customer_Data a = new Customer_Data();
                                a.InsertCustomer(o);

                                LoginData x = new LoginData();
                                x.InsertUser(u);
                                MessageBox.Show("customer inserted.customer id" + o.Customer_Id, "add customer", MessageBoxButtons.OK);
                                NameTextBox.Clear();
                                PhoneNoTextBox.Clear();
                                AddressTextBox.Clear();
                                AgeTextBox.Clear();
                                SecurityAnswerTextBox.Clear();
                                PasswordTextBox.Clear();




                                ManageCustomerDataGridView.DataSource = a.GetCustomerList();



                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show("Exception", "add customer", MessageBoxButtons.OK);
                                NameTextBox.Clear();
                                PhoneNoTextBox.Clear();
                                AddressTextBox.Clear();
                                AgeTextBox.Clear();
                                SecurityAnswerTextBox.Clear();
                                PasswordTextBox.Clear();

                            }
                        }
                        else
                        {
                            MessageBox.Show("failed.please answer the security question or provide password", "add customer", MessageBoxButtons.OK);
                            SecurityAnswerTextBox.Clear();
                            PasswordTextBox.Clear();


                        }
                    }

                    else
                    {
                        MessageBox.Show("failed.please proide gender", "add customer", MessageBoxButtons.OK);
                        SecurityAnswerTextBox.Clear();
                        PasswordTextBox.Clear();


                    }

                }

                else
                {
                    MessageBox.Show("failed.please proide Address or age", "add customer", MessageBoxButtons.OK);
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();


                }
            }
            else
            {
                MessageBox.Show("failed.please proide name or phone number", "add customer", MessageBoxButtons.OK);
                NameTextBox.Clear();
                PhoneNoTextBox.Clear();


            }
        }

        public string createId()
        {
            Random xx = new Random();
            int y = xx.Next(0, 100000);
            string a = "C-" + y;
            return a;

        }

        private void ManageCustomerDataGridView_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            Id = ManageCustomerDataGridView.SelectedRows[0].Cells[0].Value.ToString();
            NameTextBox.Text = ManageCustomerDataGridView.SelectedRows[0].Cells[1].Value.ToString();
            PhoneNoTextBox.Text = ManageCustomerDataGridView.SelectedRows[0].Cells[2].Value.ToString();
            AddressTextBox.Text = ManageCustomerDataGridView.SelectedRows[0].Cells[4].Value.ToString();
            AgeTextBox.Text = ManageCustomerDataGridView.SelectedRows[0].Cells[3].Value.ToString();


            SecurityAnswerTextBox.Text = ManageCustomerDataGridView.SelectedRows[0].Cells[7].Value.ToString();
            PasswordTextBox.Clear();
        }

        private void DeleteAdminButton_Click(object sender, EventArgs e)
        {
            if (Id != null)
            {
                try
                {
                    Customer_Data a = new Customer_Data();
                    a.DeleteCustomer(Id);

                    LoginData x = new LoginData();
                    x.UpdateUser(Id, "inactive");

                    NameTextBox.Clear();
                    PhoneNoTextBox.Clear();
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();
                    SecurityAnswerTextBox.Clear();
                    PasswordTextBox.Clear();


                    ManageCustomerDataGridView.DataSource = a.GetCustomerList();
                    MessageBox.Show("customer DELETED.customer id" + Id, "add customer", MessageBoxButtons.OK);
                    Id = null;
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception", "add customer", MessageBoxButtons.OK);
                    NameTextBox.Clear();
                    PhoneNoTextBox.Clear();
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();
                    SecurityAnswerTextBox.Clear();
                    PasswordTextBox.Clear();
                    Id = null;

                }
            }
            else
            {
                MessageBox.Show("please select an customer", "add customer", MessageBoxButtons.OK);
            }
        }

        private void UpdateCustomeButton_Click(object sender, EventArgs e)
        {
            if (Id != null)
            {
                try
                {
                    Customer_Data a = new Customer_Data();
                    a.UpdateCustomer(Id, NameTextBox.Text);



                    NameTextBox.Clear();
                    PhoneNoTextBox.Clear();
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();
                    SecurityAnswerTextBox.Clear();
                    PasswordTextBox.Clear();



                    ManageCustomerDataGridView.DataSource = a.GetCustomerList();
                    MessageBox.Show("Customer updated.Customer id" + Id, "add Customer", MessageBoxButtons.OK);
                    Id = null;

                }
                catch (Exception ex)
                {
                    MessageBox.Show("Exception", "add customer", MessageBoxButtons.OK);
                    NameTextBox.Clear();
                    PhoneNoTextBox.Clear();
                    AddressTextBox.Clear();
                    AgeTextBox.Clear();
                    SecurityAnswerTextBox.Clear();
                    PasswordTextBox.Clear();
                    Id = null;

                }
                
            }

            else
            {
                MessageBox.Show("please select an customer", "add Customer", MessageBoxButtons.OK);
            }
        }
    }
}
