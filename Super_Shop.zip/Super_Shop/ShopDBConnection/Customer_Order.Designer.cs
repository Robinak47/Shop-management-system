﻿namespace ShopDBConnection
{
    partial class Customer_Order
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CustomerOrderGroupBox = new System.Windows.Forms.GroupBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.CustomerOrderDataGridView = new System.Windows.Forms.DataGridView();
            this.CustomerOrderGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerOrderDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // CustomerOrderGroupBox
            // 
            this.CustomerOrderGroupBox.Controls.Add(this.BackButton);
            this.CustomerOrderGroupBox.Controls.Add(this.CustomerOrderDataGridView);
            this.CustomerOrderGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerOrderGroupBox.Location = new System.Drawing.Point(96, 27);
            this.CustomerOrderGroupBox.Name = "CustomerOrderGroupBox";
            this.CustomerOrderGroupBox.Size = new System.Drawing.Size(773, 645);
            this.CustomerOrderGroupBox.TabIndex = 43;
            this.CustomerOrderGroupBox.TabStop = false;
            this.CustomerOrderGroupBox.Text = "Customer Order";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(322, 560);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 40;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // CustomerOrderDataGridView
            // 
            this.CustomerOrderDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CustomerOrderDataGridView.Location = new System.Drawing.Point(26, 63);
            this.CustomerOrderDataGridView.Name = "CustomerOrderDataGridView";
            this.CustomerOrderDataGridView.RowHeadersWidth = 51;
            this.CustomerOrderDataGridView.RowTemplate.Height = 24;
            this.CustomerOrderDataGridView.Size = new System.Drawing.Size(724, 466);
            this.CustomerOrderDataGridView.TabIndex = 38;
            // 
            // Customer_Order
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.CustomerOrderGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Customer_Order";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer_Order";
            this.Load += new System.EventHandler(this.Customer_Order_Load);
            this.CustomerOrderGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CustomerOrderDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox CustomerOrderGroupBox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.DataGridView CustomerOrderDataGridView;
    }
}