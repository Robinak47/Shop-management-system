﻿namespace ShopDBConnection
{
    partial class Customer_UpdateInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CustomerUpdateInfoGroupbox = new System.Windows.Forms.GroupBox();
            this.IdTextBox = new System.Windows.Forms.TextBox();
            this.IdLabel = new System.Windows.Forms.Label();
            this.PasswordTextBox = new System.Windows.Forms.TextBox();
            this.PasswordLabel = new System.Windows.Forms.Label();
            this.BackButton = new System.Windows.Forms.Button();
            this.USubmitButton = new System.Windows.Forms.Button();
            this.PhoneNotextBox1 = new System.Windows.Forms.TextBox();
            this.phoneNoLabel = new System.Windows.Forms.Label();
            this.CustomerUpdateInfoGroupbox.SuspendLayout();
            this.SuspendLayout();
            // 
            // CustomerUpdateInfoGroupbox
            // 
            this.CustomerUpdateInfoGroupbox.Controls.Add(this.IdTextBox);
            this.CustomerUpdateInfoGroupbox.Controls.Add(this.IdLabel);
            this.CustomerUpdateInfoGroupbox.Controls.Add(this.PasswordTextBox);
            this.CustomerUpdateInfoGroupbox.Controls.Add(this.PasswordLabel);
            this.CustomerUpdateInfoGroupbox.Controls.Add(this.BackButton);
            this.CustomerUpdateInfoGroupbox.Controls.Add(this.USubmitButton);
            this.CustomerUpdateInfoGroupbox.Controls.Add(this.PhoneNotextBox1);
            this.CustomerUpdateInfoGroupbox.Controls.Add(this.phoneNoLabel);
            this.CustomerUpdateInfoGroupbox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerUpdateInfoGroupbox.Location = new System.Drawing.Point(121, 28);
            this.CustomerUpdateInfoGroupbox.Name = "CustomerUpdateInfoGroupbox";
            this.CustomerUpdateInfoGroupbox.Size = new System.Drawing.Size(722, 642);
            this.CustomerUpdateInfoGroupbox.TabIndex = 45;
            this.CustomerUpdateInfoGroupbox.TabStop = false;
            this.CustomerUpdateInfoGroupbox.Text = "Customer Update Info";
            // 
            // IdTextBox
            // 
            this.IdTextBox.Location = new System.Drawing.Point(314, 138);
            this.IdTextBox.Multiline = true;
            this.IdTextBox.Name = "IdTextBox";
            this.IdTextBox.Size = new System.Drawing.Size(200, 33);
            this.IdTextBox.TabIndex = 53;
            // 
            // IdLabel
            // 
            this.IdLabel.AutoSize = true;
            this.IdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.IdLabel.Location = new System.Drawing.Point(247, 146);
            this.IdLabel.Name = "IdLabel";
            this.IdLabel.Size = new System.Drawing.Size(28, 25);
            this.IdLabel.TabIndex = 52;
            this.IdLabel.Text = "Id";
            // 
            // PasswordTextBox
            // 
            this.PasswordTextBox.Location = new System.Drawing.Point(314, 262);
            this.PasswordTextBox.Multiline = true;
            this.PasswordTextBox.Name = "PasswordTextBox";
            this.PasswordTextBox.Size = new System.Drawing.Size(200, 33);
            this.PasswordTextBox.TabIndex = 51;
            // 
            // PasswordLabel
            // 
            this.PasswordLabel.AutoSize = true;
            this.PasswordLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PasswordLabel.Location = new System.Drawing.Point(192, 262);
            this.PasswordLabel.Name = "PasswordLabel";
            this.PasswordLabel.Size = new System.Drawing.Size(98, 25);
            this.PasswordLabel.TabIndex = 50;
            this.PasswordLabel.Text = "Password";
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(427, 346);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 39;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // USubmitButton
            // 
            this.USubmitButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.USubmitButton.Location = new System.Drawing.Point(314, 346);
            this.USubmitButton.Name = "USubmitButton";
            this.USubmitButton.Size = new System.Drawing.Size(87, 41);
            this.USubmitButton.TabIndex = 38;
            this.USubmitButton.Text = "Submit";
            this.USubmitButton.UseVisualStyleBackColor = true;
            this.USubmitButton.Click += new System.EventHandler(this.USubmitButton_Click);
            // 
            // PhoneNotextBox1
            // 
            this.PhoneNotextBox1.Location = new System.Drawing.Point(314, 199);
            this.PhoneNotextBox1.Multiline = true;
            this.PhoneNotextBox1.Name = "PhoneNotextBox1";
            this.PhoneNotextBox1.Size = new System.Drawing.Size(200, 33);
            this.PhoneNotextBox1.TabIndex = 2;
            this.PhoneNotextBox1.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PhoneNotextBox1_KeyPress);
            // 
            // phoneNoLabel
            // 
            this.phoneNoLabel.AutoSize = true;
            this.phoneNoLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.phoneNoLabel.Location = new System.Drawing.Point(190, 203);
            this.phoneNoLabel.Name = "phoneNoLabel";
            this.phoneNoLabel.Size = new System.Drawing.Size(99, 25);
            this.phoneNoLabel.TabIndex = 0;
            this.phoneNoLabel.Text = "Phone No";
            // 
            // Customer_UpdateInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.CustomerUpdateInfoGroupbox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Customer_UpdateInfo";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer_UpdateInfo";
            this.Load += new System.EventHandler(this.Customer_UpdateInfo_Load);
            this.CustomerUpdateInfoGroupbox.ResumeLayout(false);
            this.CustomerUpdateInfoGroupbox.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox CustomerUpdateInfoGroupbox;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.Button USubmitButton;
        private System.Windows.Forms.TextBox PhoneNotextBox1;
        private System.Windows.Forms.Label phoneNoLabel;
        private System.Windows.Forms.TextBox PasswordTextBox;
        private System.Windows.Forms.Label PasswordLabel;
        private System.Windows.Forms.TextBox IdTextBox;
        private System.Windows.Forms.Label IdLabel;
    }
}