﻿namespace ShopDBConnection
{
    partial class Customer_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CustomerProductGroupBox = new System.Windows.Forms.GroupBox();
            this.CustomerProductDataGridView = new System.Windows.Forms.DataGridView();
            this.BackButton = new System.Windows.Forms.Button();
            this.CustomerProductGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CustomerProductDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // CustomerProductGroupBox
            // 
            this.CustomerProductGroupBox.Controls.Add(this.BackButton);
            this.CustomerProductGroupBox.Controls.Add(this.CustomerProductDataGridView);
            this.CustomerProductGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 6F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerProductGroupBox.Location = new System.Drawing.Point(120, 28);
            this.CustomerProductGroupBox.Name = "CustomerProductGroupBox";
            this.CustomerProductGroupBox.Size = new System.Drawing.Size(724, 642);
            this.CustomerProductGroupBox.TabIndex = 42;
            this.CustomerProductGroupBox.TabStop = false;
            this.CustomerProductGroupBox.Text = "Product";
            // 
            // CustomerProductDataGridView
            // 
            this.CustomerProductDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CustomerProductDataGridView.Location = new System.Drawing.Point(29, 41);
            this.CustomerProductDataGridView.Name = "CustomerProductDataGridView";
            this.CustomerProductDataGridView.RowHeadersWidth = 51;
            this.CustomerProductDataGridView.RowTemplate.Height = 24;
            this.CustomerProductDataGridView.Size = new System.Drawing.Size(676, 507);
            this.CustomerProductDataGridView.TabIndex = 38;
            this.CustomerProductDataGridView.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CustomerProductDataGridView_CellContentClick);
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(320, 563);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 43;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // Customer_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.CustomerProductGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Customer_Product";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Customer_Product";
            this.Load += new System.EventHandler(this.Customer_Product_Load);
            this.CustomerProductGroupBox.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.CustomerProductDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox CustomerProductGroupBox;
        private System.Windows.Forms.DataGridView CustomerProductDataGridView;
        private System.Windows.Forms.Button BackButton;
    }
}