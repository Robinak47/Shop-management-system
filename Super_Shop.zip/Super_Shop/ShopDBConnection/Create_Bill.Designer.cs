﻿namespace ShopDBConnection
{
    partial class Create_Bill
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.CreateBillGroupBox = new System.Windows.Forms.GroupBox();
            this.TotalBillTextBox = new System.Windows.Forms.TextBox();
            this.TotalBillLabel = new System.Windows.Forms.Label();
            this.RemoveCurtButton = new System.Windows.Forms.Button();
            this.CustomerIdTextBox = new System.Windows.Forms.TextBox();
            this.CustomerIdLabel = new System.Windows.Forms.Label();
            this.MakeBillButton = new System.Windows.Forms.Button();
            this.BackButton = new System.Windows.Forms.Button();
            this.CreateBillDataGridView = new System.Windows.Forms.DataGridView();
            this.ProductIdTextBox = new System.Windows.Forms.TextBox();
            this.productIdLabel = new System.Windows.Forms.Label();
            this.CartButton = new System.Windows.Forms.Button();
            this.QuantityTextBox = new System.Windows.Forms.TextBox();
            this.QuantityLabel = new System.Windows.Forms.Label();
            this.CreateBillGroupBox.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CreateBillDataGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // CreateBillGroupBox
            // 
            this.CreateBillGroupBox.Controls.Add(this.TotalBillTextBox);
            this.CreateBillGroupBox.Controls.Add(this.TotalBillLabel);
            this.CreateBillGroupBox.Controls.Add(this.RemoveCurtButton);
            this.CreateBillGroupBox.Controls.Add(this.CustomerIdTextBox);
            this.CreateBillGroupBox.Controls.Add(this.CustomerIdLabel);
            this.CreateBillGroupBox.Controls.Add(this.MakeBillButton);
            this.CreateBillGroupBox.Controls.Add(this.BackButton);
            this.CreateBillGroupBox.Controls.Add(this.CreateBillDataGridView);
            this.CreateBillGroupBox.Controls.Add(this.ProductIdTextBox);
            this.CreateBillGroupBox.Controls.Add(this.productIdLabel);
            this.CreateBillGroupBox.Controls.Add(this.CartButton);
            this.CreateBillGroupBox.Controls.Add(this.QuantityTextBox);
            this.CreateBillGroupBox.Controls.Add(this.QuantityLabel);
            this.CreateBillGroupBox.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CreateBillGroupBox.Location = new System.Drawing.Point(80, 35);
            this.CreateBillGroupBox.Name = "CreateBillGroupBox";
            this.CreateBillGroupBox.Size = new System.Drawing.Size(805, 628);
            this.CreateBillGroupBox.TabIndex = 46;
            this.CreateBillGroupBox.TabStop = false;
            this.CreateBillGroupBox.Text = "Create Bill";
            this.CreateBillGroupBox.Enter += new System.EventHandler(this.CreateBillGroupBox_Enter);
            // 
            // TotalBillTextBox
            // 
            this.TotalBillTextBox.Location = new System.Drawing.Point(501, 23);
            this.TotalBillTextBox.Multiline = true;
            this.TotalBillTextBox.Name = "TotalBillTextBox";
            this.TotalBillTextBox.ReadOnly = true;
            this.TotalBillTextBox.Size = new System.Drawing.Size(200, 33);
            this.TotalBillTextBox.TabIndex = 55;
            // 
            // TotalBillLabel
            // 
            this.TotalBillLabel.AutoSize = true;
            this.TotalBillLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TotalBillLabel.Location = new System.Drawing.Point(383, 23);
            this.TotalBillLabel.Name = "TotalBillLabel";
            this.TotalBillLabel.Size = new System.Drawing.Size(86, 25);
            this.TotalBillLabel.TabIndex = 54;
            this.TotalBillLabel.Text = "Total Bill";
            // 
            // RemoveCurtButton
            // 
            this.RemoveCurtButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.RemoveCurtButton.Location = new System.Drawing.Point(453, 329);
            this.RemoveCurtButton.Name = "RemoveCurtButton";
            this.RemoveCurtButton.Size = new System.Drawing.Size(163, 42);
            this.RemoveCurtButton.TabIndex = 53;
            this.RemoveCurtButton.Text = "remove curt";
            this.RemoveCurtButton.UseVisualStyleBackColor = true;
            this.RemoveCurtButton.Click += new System.EventHandler(this.RemoveCurtButton_Click);
            // 
            // CustomerIdTextBox
            // 
            this.CustomerIdTextBox.Location = new System.Drawing.Point(140, 23);
            this.CustomerIdTextBox.Multiline = true;
            this.CustomerIdTextBox.Name = "CustomerIdTextBox";
            this.CustomerIdTextBox.Size = new System.Drawing.Size(200, 33);
            this.CustomerIdTextBox.TabIndex = 50;
            // 
            // CustomerIdLabel
            // 
            this.CustomerIdLabel.AutoSize = true;
            this.CustomerIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CustomerIdLabel.Location = new System.Drawing.Point(22, 23);
            this.CustomerIdLabel.Name = "CustomerIdLabel";
            this.CustomerIdLabel.Size = new System.Drawing.Size(112, 25);
            this.CustomerIdLabel.TabIndex = 49;
            this.CustomerIdLabel.Text = "customer id";
            // 
            // MakeBillButton
            // 
            this.MakeBillButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.MakeBillButton.Location = new System.Drawing.Point(230, 329);
            this.MakeBillButton.Name = "MakeBillButton";
            this.MakeBillButton.Size = new System.Drawing.Size(163, 42);
            this.MakeBillButton.TabIndex = 48;
            this.MakeBillButton.Text = "Make Bill";
            this.MakeBillButton.UseVisualStyleBackColor = true;
            this.MakeBillButton.Click += new System.EventHandler(this.MakeBillButton_Click);
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(651, 330);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(87, 41);
            this.BackButton.TabIndex = 46;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // CreateBillDataGridView
            // 
            this.CreateBillDataGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.CreateBillDataGridView.Location = new System.Drawing.Point(48, 391);
            this.CreateBillDataGridView.Name = "CreateBillDataGridView";
            this.CreateBillDataGridView.RowHeadersWidth = 51;
            this.CreateBillDataGridView.RowTemplate.Height = 24;
            this.CreateBillDataGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.CreateBillDataGridView.Size = new System.Drawing.Size(720, 214);
            this.CreateBillDataGridView.TabIndex = 47;
            this.CreateBillDataGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.CreateBillDataGridView_CellClick);
            // 
            // ProductIdTextBox
            // 
            this.ProductIdTextBox.Location = new System.Drawing.Point(140, 88);
            this.ProductIdTextBox.Multiline = true;
            this.ProductIdTextBox.Name = "ProductIdTextBox";
            this.ProductIdTextBox.Size = new System.Drawing.Size(200, 33);
            this.ProductIdTextBox.TabIndex = 41;
            // 
            // productIdLabel
            // 
            this.productIdLabel.AutoSize = true;
            this.productIdLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productIdLabel.Location = new System.Drawing.Point(23, 96);
            this.productIdLabel.Name = "productIdLabel";
            this.productIdLabel.Size = new System.Drawing.Size(100, 25);
            this.productIdLabel.TabIndex = 40;
            this.productIdLabel.Text = "Product Id";
            // 
            // CartButton
            // 
            this.CartButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.CartButton.Location = new System.Drawing.Point(28, 329);
            this.CartButton.Name = "CartButton";
            this.CartButton.Size = new System.Drawing.Size(163, 42);
            this.CartButton.TabIndex = 38;
            this.CartButton.Text = "ADD Curt";
            this.CartButton.UseVisualStyleBackColor = true;
            this.CartButton.Click += new System.EventHandler(this.CartButton_Click);
            // 
            // QuantityTextBox
            // 
            this.QuantityTextBox.Location = new System.Drawing.Point(140, 154);
            this.QuantityTextBox.Multiline = true;
            this.QuantityTextBox.Name = "QuantityTextBox";
            this.QuantityTextBox.Size = new System.Drawing.Size(200, 33);
            this.QuantityTextBox.TabIndex = 2;
            this.QuantityTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.QuantityTextBox_KeyPress);
            // 
            // QuantityLabel
            // 
            this.QuantityLabel.AutoSize = true;
            this.QuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityLabel.Location = new System.Drawing.Point(23, 162);
            this.QuantityLabel.Name = "QuantityLabel";
            this.QuantityLabel.Size = new System.Drawing.Size(85, 25);
            this.QuantityLabel.TabIndex = 0;
            this.QuantityLabel.Text = "Quantity";
            // 
            // Create_Bill
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.CreateBillGroupBox);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Create_Bill";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Create_Bill";
            this.Load += new System.EventHandler(this.Create_Bill_Load);
            this.CreateBillGroupBox.ResumeLayout(false);
            this.CreateBillGroupBox.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.CreateBillDataGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox CreateBillGroupBox;
        private System.Windows.Forms.Button MakeBillButton;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.DataGridView CreateBillDataGridView;
        private System.Windows.Forms.TextBox ProductIdTextBox;
        private System.Windows.Forms.Label productIdLabel;
        private System.Windows.Forms.Button CartButton;
        private System.Windows.Forms.TextBox QuantityTextBox;
        private System.Windows.Forms.Label QuantityLabel;
        private System.Windows.Forms.TextBox CustomerIdTextBox;
        private System.Windows.Forms.Label CustomerIdLabel;
        private System.Windows.Forms.Button RemoveCurtButton;
        private System.Windows.Forms.TextBox TotalBillTextBox;
        private System.Windows.Forms.Label TotalBillLabel;
    }
}