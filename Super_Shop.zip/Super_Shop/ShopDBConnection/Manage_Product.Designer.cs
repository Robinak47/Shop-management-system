﻿namespace ShopDBConnection
{
    partial class Manage_Product
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ManageProductGroupBox1 = new System.Windows.Forms.GroupBox();
            this.BackButton = new System.Windows.Forms.Button();
            this.ManageProductGridView = new System.Windows.Forms.DataGridView();
            this.UpdateProductButton = new System.Windows.Forms.Button();
            this.DeleteproductButton = new System.Windows.Forms.Button();
            this.AddProductButton = new System.Windows.Forms.Button();
            this.PriceTextBox = new System.Windows.Forms.TextBox();
            this.PriceLabel = new System.Windows.Forms.Label();
            this.QuantityTextbox = new System.Windows.Forms.TextBox();
            this.QuantityLabel = new System.Windows.Forms.Label();
            this.ProductNameTextBox = new System.Windows.Forms.TextBox();
            this.productNameLabel = new System.Windows.Forms.Label();
            this.ManageProductGroupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ManageProductGridView)).BeginInit();
            this.SuspendLayout();
            // 
            // ManageProductGroupBox1
            // 
            this.ManageProductGroupBox1.Controls.Add(this.BackButton);
            this.ManageProductGroupBox1.Controls.Add(this.ManageProductGridView);
            this.ManageProductGroupBox1.Controls.Add(this.UpdateProductButton);
            this.ManageProductGroupBox1.Controls.Add(this.DeleteproductButton);
            this.ManageProductGroupBox1.Controls.Add(this.AddProductButton);
            this.ManageProductGroupBox1.Controls.Add(this.PriceTextBox);
            this.ManageProductGroupBox1.Controls.Add(this.PriceLabel);
            this.ManageProductGroupBox1.Controls.Add(this.QuantityTextbox);
            this.ManageProductGroupBox1.Controls.Add(this.QuantityLabel);
            this.ManageProductGroupBox1.Controls.Add(this.ProductNameTextBox);
            this.ManageProductGroupBox1.Controls.Add(this.productNameLabel);
            this.ManageProductGroupBox1.Location = new System.Drawing.Point(41, 25);
            this.ManageProductGroupBox1.Name = "ManageProductGroupBox1";
            this.ManageProductGroupBox1.Size = new System.Drawing.Size(902, 651);
            this.ManageProductGroupBox1.TabIndex = 0;
            this.ManageProductGroupBox1.TabStop = false;
            this.ManageProductGroupBox1.Text = "Manage Product";
            this.ManageProductGroupBox1.Enter += new System.EventHandler(this.ManageProductGroupBox1_Enter);
            // 
            // BackButton
            // 
            this.BackButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BackButton.Location = new System.Drawing.Point(704, 319);
            this.BackButton.Name = "BackButton";
            this.BackButton.Size = new System.Drawing.Size(158, 43);
            this.BackButton.TabIndex = 10;
            this.BackButton.Text = "Back";
            this.BackButton.UseVisualStyleBackColor = true;
            this.BackButton.Click += new System.EventHandler(this.BackButton_Click);
            // 
            // ManageProductGridView
            // 
            this.ManageProductGridView.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.ManageProductGridView.Location = new System.Drawing.Point(34, 385);
            this.ManageProductGridView.Name = "ManageProductGridView";
            this.ManageProductGridView.RowHeadersWidth = 51;
            this.ManageProductGridView.RowTemplate.Height = 24;
            this.ManageProductGridView.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.ManageProductGridView.Size = new System.Drawing.Size(852, 249);
            this.ManageProductGridView.TabIndex = 9;
            this.ManageProductGridView.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.ManageProductGridView_CellClick);
            // 
            // UpdateProductButton
            // 
            this.UpdateProductButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.UpdateProductButton.Location = new System.Drawing.Point(281, 319);
            this.UpdateProductButton.Name = "UpdateProductButton";
            this.UpdateProductButton.Size = new System.Drawing.Size(164, 41);
            this.UpdateProductButton.TabIndex = 8;
            this.UpdateProductButton.Text = "Update Product";
            this.UpdateProductButton.UseVisualStyleBackColor = true;
            this.UpdateProductButton.Click += new System.EventHandler(this.UpdateProductButton_Click);
            // 
            // DeleteproductButton
            // 
            this.DeleteproductButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.DeleteproductButton.Location = new System.Drawing.Point(494, 319);
            this.DeleteproductButton.Name = "DeleteproductButton";
            this.DeleteproductButton.Size = new System.Drawing.Size(158, 43);
            this.DeleteproductButton.TabIndex = 7;
            this.DeleteproductButton.Text = "Delete Product";
            this.DeleteproductButton.UseVisualStyleBackColor = true;
            this.DeleteproductButton.Click += new System.EventHandler(this.DeleteproductButton_Click);
            // 
            // AddProductButton
            // 
            this.AddProductButton.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.AddProductButton.Location = new System.Drawing.Point(87, 319);
            this.AddProductButton.Name = "AddProductButton";
            this.AddProductButton.Size = new System.Drawing.Size(146, 41);
            this.AddProductButton.TabIndex = 6;
            this.AddProductButton.Text = "Add product";
            this.AddProductButton.UseVisualStyleBackColor = true;
            this.AddProductButton.Click += new System.EventHandler(this.AddProductButton_Click);
            // 
            // PriceTextBox
            // 
            this.PriceTextBox.Location = new System.Drawing.Point(373, 216);
            this.PriceTextBox.Multiline = true;
            this.PriceTextBox.Name = "PriceTextBox";
            this.PriceTextBox.Size = new System.Drawing.Size(205, 36);
            this.PriceTextBox.TabIndex = 5;
            this.PriceTextBox.TextChanged += new System.EventHandler(this.PriceTextBox_TextChanged);
            this.PriceTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.PriceTextBox_KeyPress);
            // 
            // PriceLabel
            // 
            this.PriceLabel.AutoSize = true;
            this.PriceLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.PriceLabel.Location = new System.Drawing.Point(278, 220);
            this.PriceLabel.Name = "PriceLabel";
            this.PriceLabel.Size = new System.Drawing.Size(61, 25);
            this.PriceLabel.TabIndex = 4;
            this.PriceLabel.Text = "Price";
            // 
            // QuantityTextbox
            // 
            this.QuantityTextbox.Location = new System.Drawing.Point(373, 154);
            this.QuantityTextbox.Multiline = true;
            this.QuantityTextbox.Name = "QuantityTextbox";
            this.QuantityTextbox.Size = new System.Drawing.Size(205, 36);
            this.QuantityTextbox.TabIndex = 3;
            this.QuantityTextbox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.QuantityTextbox_KeyPress);
            // 
            // QuantityLabel
            // 
            this.QuantityLabel.AutoSize = true;
            this.QuantityLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.QuantityLabel.Location = new System.Drawing.Point(258, 159);
            this.QuantityLabel.Name = "QuantityLabel";
            this.QuantityLabel.Size = new System.Drawing.Size(93, 25);
            this.QuantityLabel.TabIndex = 2;
            this.QuantityLabel.Text = "Quantity";
            // 
            // ProductNameTextBox
            // 
            this.ProductNameTextBox.Location = new System.Drawing.Point(373, 90);
            this.ProductNameTextBox.Multiline = true;
            this.ProductNameTextBox.Name = "ProductNameTextBox";
            this.ProductNameTextBox.Size = new System.Drawing.Size(205, 36);
            this.ProductNameTextBox.TabIndex = 1;
            this.ProductNameTextBox.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.ProductNameTextBox_KeyPress);
            // 
            // productNameLabel
            // 
            this.productNameLabel.AutoSize = true;
            this.productNameLabel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.productNameLabel.Location = new System.Drawing.Point(215, 94);
            this.productNameLabel.Name = "productNameLabel";
            this.productNameLabel.Size = new System.Drawing.Size(148, 25);
            this.productNameLabel.TabIndex = 0;
            this.productNameLabel.Text = "Product Name";
            // 
            // Manage_Product
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(192)))), ((int)(((byte)(255)))), ((int)(((byte)(255)))));
            this.ClientSize = new System.Drawing.Size(964, 699);
            this.Controls.Add(this.ManageProductGroupBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Manage_Product";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Manage_Product";
            this.Load += new System.EventHandler(this.Manage_Product_Load);
            this.ManageProductGroupBox1.ResumeLayout(false);
            this.ManageProductGroupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.ManageProductGridView)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.GroupBox ManageProductGroupBox1;
        private System.Windows.Forms.Button BackButton;
        private System.Windows.Forms.DataGridView ManageProductGridView;
        private System.Windows.Forms.Button UpdateProductButton;
        private System.Windows.Forms.Button DeleteproductButton;
        private System.Windows.Forms.Button AddProductButton;
        private System.Windows.Forms.TextBox PriceTextBox;
        private System.Windows.Forms.Label PriceLabel;
        private System.Windows.Forms.TextBox QuantityTextbox;
        private System.Windows.Forms.Label QuantityLabel;
        private System.Windows.Forms.TextBox ProductNameTextBox;
        private System.Windows.Forms.Label productNameLabel;
    }
}