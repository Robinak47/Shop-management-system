﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Entities
{
    public class User
    {
        public string UserId { get; set; }
        public string Password { get; set; }
        public string Active_status { get; set; }
        public int Status { get; set; }
        public string Security{ get; set; }
    }
}
