﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Entities
{
    public class OrderD
    {
        public string orderId { get; set; }
        public string Customer_Id { get; set; }
        public int Total_Amount{ get; set; }

    }


}
