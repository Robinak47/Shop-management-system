﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Entities
{
    public class EmployeeD
    {
        public string Employee_Id { get; set; }
        public string Employee_Name { get; set; }
        public int Employee_Phone { get; set; }
        public int Employee_Age { get; set; }
        public string Employee_Addresss { get; set; }
        public string Employee_Gender { get; set; }
        public string Employee_Designation { get; set; }
        public int Employee_Salary { get; set; }
        public string Employee_Security { get; set; }
        public string Employee_Status { get; set; }


    }
}
