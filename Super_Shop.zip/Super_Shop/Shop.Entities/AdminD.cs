﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Shop.Entities
{
    public class AdminD
    {
        public string Admin_Id { get; set; }
        public string Admin_Name{ get; set; }
       public int Admin_Phone{ get; set; }
        public int Admin_Age{ get; set; }
        public string Admin_Address{ get; set; }
        public string Admin_Gender{ get; set; }
        public string Admin_ActiveStatus{ get; set; }
        public string Admin_Security{ get; set; }




    }
}
